# RUGER BOT

A modular WhatsApp automation bot built on Node.js + [Baileys](https://github.com/WhiskeySockets/Baileys).

## Setup

```bash
npm install
cp .env.example .env   # then edit .env with your details
npm start
```

On first run, if `USE_PAIRING_CODE=true` (default), you'll be prompted for your
WhatsApp number and given an 8-character pairing code to enter in
**WhatsApp → Linked Devices → Link with phone number**. Set `USE_PAIRING_CODE=false`
to get a QR code instead.

## Project layout

```
RUGER-BOT/
├── index.js              # connection, event wiring, command dispatcher
├── config.js              # bot name, prefix, owner, defaults
├── commands/
│   ├── main/               # menu, help, ping, alive, runtime, owner, settings, pair, restart
│   ├── group/               # kick/add/promote/demote/tagall/hidetag/mute/warn/welcome/etc.
│   ├── anti/                 # antilink, antispam, antibot, antifake, antitag, antibadword, anticall
│   ├── media/                  # sticker/voice/media conversion, getpp/getstatus
│   ├── download/                # tiktok/instagram/facebook/twitter/youtube/mediafire/play
│   ├── utility/                   # weather/calc/genpass/translate/tts/etc.
│   ├── owner/                      # broadcast/sudo/mode/automation/profile settings/accountnumber
│   └── fun/                         # joke/quote/meme/games
├── database/                # JSON-file storage (settings, warnings, per-group config)
├── plugins/                  # drop-in third-party command files, auto-loaded
├── sessions/                   # Baileys auth state (do not commit)
└── utils/                        # database, permissions, media, ffmpeg, downloader, logger
```

## Adding commands / plugins

Any `.js` file placed in `plugins/` (or `commands/**`) that exports an object
(or array of objects) shaped like this is auto-loaded on boot:

```js
module.exports = {
  name: 'hello',
  aliases: ['hi'],
  category: 'fun',
  description: 'Say hello.',
  usage: '.hello',
  ownerOnly: false,   // optional
  groupOnly: false,   // optional
  adminOnly: false,   // optional
  execute: async (ctx) => {
    await ctx.reply('Hello!');
  },
};
```

`ctx` gives you `sock`, `msg`, `from`, `sender`, `args`, `fullArgs`, `isGroup`,
`groupMetadata`, `isOwnerOrSudo`, `isSenderAdmin`, `mentionedJid`, `quoted`, and `reply()`.

## What's intentionally not included

This build does **not** include hidden/silent message-recovery features
(auto-capturing deleted messages, edited-message diffing, forwarded-message
logging, or View-Once media capture to a private "owner inbox"). Those
features covertly intercept content the sender deleted, edited, or marked
view-once — defeating the privacy mechanism WhatsApp built for exactly that
purpose — regardless of who operates the bot. The `.forward` command that
**is** included only forwards a message the operator explicitly replies to
and chooses to send elsewhere; it does not intercept anything automatically
or silently.

If you want deleted/edited-message *moderation logging*, a transparent
version — posted visibly back into the same chat, with no silent mode and no
separate private inbox — can be added on request.

## Profile picture & status commands

- **`.getpp`** (aliases `.pp`, `.profilepic`, `.getdp`) fetches and sends
  someone's current WhatsApp profile picture — yourself by default, or
  `@mention` / reply / a phone number. This only works if that picture is
  visible to the bot's account under their privacy settings, same as opening
  their profile in the WhatsApp app.
- **`.getstatus`** (aliases `.savestatus`, `.statusdl`) resends the most
  recent Status update the bot has actually seen come through for a contact.
  It does not fetch anything retroactively or bypass WhatsApp's 24‑hour
  Status visibility — it only remembers, in memory, the last status update
  that already reached the bot, so it can hand that back on request. Turn on
  `.autoviewstatus on` (owner-only) so the bot starts seeing/caching statuses
  from your contacts; `.statusdelay <seconds>` controls how long it waits
  before marking a status as viewed.

## Account / payment details

- **`.setaccount Name|Number|Network`** (owner-only) saves your payment
  details.
- **`.accountnumber`** (aliases `.aza`, `.account`, `.momo`) — anyone can run
  this to see those saved details, e.g. for sending money to the bot owner.

## Auto-like status

- **`.autolikestatus on|off`** (owner-only) automatically reacts to a
  contact's status update with an emoji as it comes through — same
  mechanism/visibility as `.autoviewstatus`, just a reaction instead of a
  read receipt.
- **`.setstatusemoji <emoji>`** (owner-only) picks the emoji used.

## Tic Tac Toe

`.tictactoe @user` (alias `.ttt`) starts a real, fully playable match against
another group member — turns alternate automatically, `.move <1-9>` (alias
`.mv`) places a mark, and the board re-renders after every move until there's
a winner or a draw. `.tictactoe cancel` ends a stuck game. One game runs per
chat at a time; state lives in memory and resets on restart.

## New utility commands

- **`.qrcode <text>`** (alias `.qr`) — generate a QR code image.
- **`.currency <amount> <from> <to>`** (aliases `.convert`, `.exchange`) —
  live currency conversion.
- **`.wiki <topic>`** (alias `.wikipedia`) — short Wikipedia summary.
- **`.define <word>`** (alias `.dictionary`) — English dictionary lookup.
- **`.jid [@user]`** — show the current chat's JID and a mentioned/replied
  user's JID (handy for debugging/plugin development).
- **`.remind <minutes> <text>`** (alias `.reminder`) — the bot messages you
  back after N minutes; in-memory only, cleared on restart.

## New group commands

- **`.setgname <name>`** (aliases `.setgroupname`, `.setsubject`) — change
  the group's name.
- **`.setgdesc <text>`** (aliases `.setgroupdesc`, `.setdescription`) —
  change the group's description.

## Notes on external integrations

- **Downloaders** (`tiktok`, `instagram`, `facebook`, `twitter`, `youtube`,
  `ytmp3`, `ytmp4`, `mediafire`, `play`, `song`, `video`) call out to a
  downloader wrapper in `utils/downloader.js`. Swap in your preferred
  provider/API keys there — no scraper credentials are bundled.
- **Weather / translate / TTS** utility commands call third-party
  services — check `commands/utility/tools.js` for the exact endpoints and
  add API keys via `.env` if the provider requires them.
- Media conversion (stickers, voice notes, MP3, MP4/GIF) runs locally via
  `ffmpeg-static` + `fluent-ffmpeg` — no external service needed.

## Owner & sudo

Set `OWNER_NUMBER` in `.env`. Additional trusted users can be added at
runtime with `.addsudo <number>` (owner-only), and removed with `.delsudo`.

## Public pairing site (let other people get their own bot)

By default `npm start` runs **one** personal bot tied to the number in `.env`.
`npm run web` instead runs a small website where **anyone** can type their own
WhatsApp number and get their own pairing code — each person's bot session
(auth, database, settings, warnings, sudo list) is fully isolated from
everyone else's, all inside the same running process.

```bash
npm install
cp .env.example .env   # PORT / MAX_SESSIONS / PAIR_COOLDOWN_MS are optional
npm run web
```

Then visit `http://localhost:3000` (or your deployed URL). Whoever you share
that link with:
1. Types their WhatsApp number.
2. Gets an 8-character code.
3. Opens WhatsApp → Linked Devices → Link with phone number → enters it.
4. Their own bot is now live, running their own copy of every command in
   this repo, under their own number as owner.

**Why this is safe by design:** a pairing code only *works* if it's typed
into WhatsApp on the phone that actually owns that number. Requesting a code
for someone else's number can't link anything to it — it can only show them
an unwanted "Link a device?" prompt, which is why `/api/pair` is rate-limited
per IP (`RATE_LIMIT_MAX` requests per 10 minutes in `server.js`) and per
number (`PAIR_COOLDOWN_MS` in `.env`).

**Capacity:** `MAX_SESSIONS` in `.env` caps how many people can be linked at
once (default 25) — each linked session is a persistent connection held in
memory. Raise it if your host has the RAM/CPU for it; each session is
lightweight but not free.

**Owner-only commands are per-person:** `.restart` and `.clearsession` only
affect the caller's own session in web mode — they don't restart the whole
server for everyone else.

### Where to host it

This needs a host that keeps a Node process running continuously (Baileys
holds a live WebSocket per session) and gives it persistent disk for the
`sessions/` and `database/` folders — not a serverless/edge platform.

- **Fly.io** (recommended for a first deploy): free-tier-friendly, a `fly volumes create` gives you persistent storage that survives restarts, and `fly deploy` builds straight from this repo with a Dockerfile. Good docs for exactly this "long-running Node process + volume" shape.
- **Railway / Render**: also fine — pick a plan with a persistent volume/disk, not the free ephemeral-filesystem tier, or your linked sessions will vanish on every redeploy.
- **A VPS you already have** (DigitalOcean, Hetzner, etc.): most control, use `pm2` or a `systemd` service to keep `npm run web` running and restart it on crash.

Whichever you pick, treat `sessions/` and `database/` as the state that must
persist — losing that folder logs every linked person out and wipes their
settings.

## License

MIT — for your own personal/group use. Respect WhatsApp's Terms of Service;
this project uses an unofficial protocol implementation (Baileys), which
carries a risk of the connected number being flagged or banned. Use a
secondary/test number, not your primary one.
