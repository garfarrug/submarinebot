/**
 * Per-session async context.
 *
 * The bot process can now host many independent WhatsApp sessions at once
 * (one per paired number). Everything that touches "which bot account is
 * this" — the owner number, the database directory, the prefix — needs to
 * resolve to the *current* session, not one global value.
 *
 * Rather than threading a `session` object through every command file,
 * we stash it in Node's AsyncLocalStorage for the lifetime of each event
 * callback (message handler, connection update, etc). Anything read
 * synchronously further down the call stack — config.js, utils/database.js —
 * can look it up via getStore().
 */
const { AsyncLocalStorage } = require('async_hooks');

const als = new AsyncLocalStorage();

/** Run fn() with `store` bound as the active session context. */
function run(store, fn) {
  return als.run(store, fn);
}

/** Returns the active session's store, or undefined outside any session. */
function getStore() {
  return als.getStore();
}

module.exports = { run, getStore };
