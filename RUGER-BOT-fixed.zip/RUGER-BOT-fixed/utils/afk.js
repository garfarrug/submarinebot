/**
 * Per-user AFK status, backed by the existing JSON db (users.json).
 * Used by the `.afk` command (commands/private/personal.js) and the
 * auto-notify hook wired into botCore.js's messages.upsert handler.
 */
const db = require('./database');

function safeKey(jid) {
  return `afk.${jid.replace(/[.@:]/g, '_')}`;
}

function get(jid) {
  return db.getPath('users', safeKey(jid), null);
}

function set(jid, reason) {
  db.setPath('users', safeKey(jid), { reason: reason || 'AFK', since: Date.now() });
}

function clear(jid) {
  db.setPath('users', safeKey(jid), null);
}

module.exports = { get, set, clear };
