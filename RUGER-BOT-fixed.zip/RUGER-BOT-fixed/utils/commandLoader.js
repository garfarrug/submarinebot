const fs = require('fs');
const path = require('path');

/**
 * Recursively loads every .js file under commands/ into a single Map keyed
 * by command name, with aliases pointing to the same entry.
 */
function loadCommands(baseDir) {
  const commands = new Map();

  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else if (entry.name.endsWith('.js')) {
        const mod = require(full);
        const list = Array.isArray(mod) ? mod : [mod];
        for (const cmd of list) {
          if (!cmd || !cmd.name) continue;
          commands.set(cmd.name, cmd);
          for (const alias of cmd.aliases || []) {
            commands.set(alias, cmd);
          }
        }
      }
    }
  }

  walk(baseDir);
  return commands;
}

module.exports = { loadCommands };
