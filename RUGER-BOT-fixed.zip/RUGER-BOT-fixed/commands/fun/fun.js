const axios = require('axios');

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const joke = {
  name: 'joke',
  category: 'fun',
  description: 'Get a random joke.',
  usage: '.joke',
  execute: async (ctx) => {
    try {
      const res = await axios.get('https://official-joke-api.appspot.com/random_joke');
      await ctx.reply(`😂 ${res.data.setup}\n\n${res.data.punchline}`);
    } catch {
      await ctx.reply('😂 Why did the developer go broke? Because he used up all his cache.');
    }
  },
};

const quote = {
  name: 'quote',
  category: 'fun',
  description: 'Get a random inspirational quote.',
  usage: '.quote',
  execute: async (ctx) => {
    try {
      const res = await axios.get('https://api.quotable.io/random');
      await ctx.reply(`💬 "${res.data.content}"\n— ${res.data.author}`);
    } catch {
      await ctx.reply('💬 "The best way to predict the future is to create it."');
    }
  },
};

const meme = {
  name: 'meme',
  aliases: ['animeme'],
  category: 'fun',
  description: 'Fetch a random meme image.',
  usage: '.meme',
  execute: async (ctx) => {
    try {
      const res = await axios.get('https://meme-api.com/gimme');
      await ctx.sock.sendMessage(ctx.from, { image: { url: res.data.url }, caption: res.data.title }, { quoted: ctx.msg });
    } catch (e) {
      await ctx.reply(`❌ Could not fetch a meme right now: ${e.message}`);
    }
  },
};

const pickupline = {
  name: 'pickupline',
  category: 'fun',
  description: 'Get a random pickup line.',
  usage: '.pickupline',
  execute: async (ctx) => {
    const lines = [
      'Are you a parking ticket? Because you’ve got fine written all over you.',
      'Do you have a map? I keep getting lost in your eyes.',
      'Is your name Wi-Fi? Because I’m really feeling a connection.',
      'Are you made of copper and tellurium? Because you’re Cu-Te.',
    ];
    await ctx.reply(pick(lines));
  },
};

const truth = {
  name: 'truth',
  category: 'fun',
  description: 'Get a random truth question.',
  usage: '.truth',
  execute: async (ctx) => {
    const list = [
      'What is your biggest fear?',
      'What is the most embarrassing thing that happened to you?',
      'Who was your first crush?',
      'What is one secret you have never told anyone?',
    ];
    await ctx.reply(`🎯 Truth: ${pick(list)}`);
  },
};

const dare = {
  name: 'dare',
  category: 'fun',
  description: 'Get a random dare challenge.',
  usage: '.dare',
  execute: async (ctx) => {
    const list = [
      'Send the last photo in your gallery.',
      'Text your crush "I like you" (or pretend to).',
      'Sing a song out loud right now.',
      'Do 10 push-ups.',
    ];
    await ctx.reply(`🔥 Dare: ${pick(list)}`);
  },
};

const ship = {
  name: 'ship',
  category: 'fun',
  description: 'Compatibility calculator between two names.',
  usage: '.ship <name1> <name2>',
  example: '.ship John Sarah',
  execute: async (ctx) => {
    if (ctx.args.length < 2) return ctx.reply('Usage: .ship <name1> <name2>');
    const [a, b] = ctx.args;
    const pct = Math.abs((a + b).split('').reduce((s, c) => s + c.charCodeAt(0), 0)) % 101;
    await ctx.reply(`💘 ${a} + ${b} = ${pct}% compatible`);
  },
};

const guess = {
  name: 'guess',
  category: 'fun',
  description: 'Guess a number between 1 and 10.',
  usage: '.guess <number>',
  execute: async (ctx) => {
    const n = Math.floor(Math.random() * 10) + 1;
    const g = parseInt(ctx.args[0], 10);
    if (Number.isNaN(g)) return ctx.reply('Usage: .guess <number 1-10>');
    await ctx.reply(g === n ? `🎉 Correct! The number was ${n}.` : `❌ Wrong! The number was ${n}.`);
  },
};

const math = {
  name: 'math',
  category: 'fun',
  description: 'Get a random math challenge.',
  usage: '.math',
  execute: async (ctx) => {
    const a = Math.floor(Math.random() * 50) + 1;
    const b = Math.floor(Math.random() * 50) + 1;
    const op = pick(['+', '-', '*']);
    await ctx.reply(`🧮 Solve: ${a} ${op} ${b} = ?`);
  },
};

const trivia = {
  name: 'trivia',
  category: 'fun',
  description: 'Get a random trivia question.',
  usage: '.trivia',
  execute: async (ctx) => {
    try {
      const res = await axios.get('https://opentdb.com/api.php?amount=1&type=multiple');
      const q = res.data.results[0];
      const options = [...q.incorrect_answers, q.correct_answer].sort(() => Math.random() - 0.5);
      await ctx.reply(`❓ ${q.question}\n\n${options.map((o, i) => `${i + 1}. ${o}`).join('\n')}`);
    } catch (e) {
      await ctx.reply(`❌ Could not fetch trivia: ${e.message}`);
    }
  },
};

const rps = {
  name: 'rps',
  category: 'fun',
  description: 'Play Rock Paper Scissors against the bot.',
  usage: '.rps <rock|paper|scissors>',
  example: '.rps rock',
  execute: async (ctx) => {
    const choices = ['rock', 'paper', 'scissors'];
    const user = (ctx.args[0] || '').toLowerCase();
    if (!choices.includes(user)) return ctx.reply('Usage: .rps <rock|paper|scissors>');
    const bot = pick(choices);
    let result;
    if (user === bot) result = "It's a tie!";
    else if ((user === 'rock' && bot === 'scissors') || (user === 'paper' && bot === 'rock') || (user === 'scissors' && bot === 'paper'))
      result = 'You win! 🎉';
    else result = 'I win! 🤖';
    await ctx.reply(`You: ${user}\nRUGER: ${bot}\n\n${result}`);
  },
};

const wouldyourather = {
  name: 'wouldyourather',
  category: 'fun',
  description: 'Get a random "would you rather" question.',
  usage: '.wouldyourather',
  execute: async (ctx) => {
    const list = [
      'Would you rather have the ability to fly or be invisible?',
      'Would you rather always be 10 minutes late or 20 minutes early?',
      'Would you rather lose all your money or all your photos?',
    ];
    await ctx.reply(`🤔 ${pick(list)}`);
  },
};

// ---- Tic Tac Toe: real playable engine (one active game per chat) ----
const tttGames = new Map(); // chatJid -> { board: Array(9), players: {X, O}, turn: 'X'|'O' }

const WIN_LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
  [0, 4, 8], [2, 4, 6],           // diagonals
];

function tttCheckWinner(board) {
  for (const [a, b, c] of WIN_LINES) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  return null;
}

function tttRenderBoard(board) {
  const cellText = (v, i) => (v === 'X' ? '❌' : v === 'O' ? '⭕' : `${i + 1}\u20E3`);
  const rows = [0, 1, 2].map((r) =>
    [0, 1, 2].map((c) => cellText(board[r * 3 + c], r * 3 + c)).join(' ')
  );
  return rows.join('\n');
}

const tictactoe = {
  name: 'tictactoe',
  aliases: ['ttt'],
  category: 'fun',
  groupOnly: true,
  description: 'Start a real Tic Tac Toe match against another member (or cancel one in progress).',
  usage: '.tictactoe @user | .tictactoe cancel',
  example: '.tictactoe @John',
  execute: async (ctx) => {
    if ((ctx.args[0] || '').toLowerCase() === 'cancel') {
      if (!tttGames.has(ctx.from)) return ctx.reply('There is no active Tic Tac Toe game in this chat.');
      tttGames.delete(ctx.from);
      return ctx.reply('🛑 Tic Tac Toe game cancelled.');
    }

    const opponent = ctx.mentionedJid?.[0];
    if (!opponent) return ctx.reply('Usage: .tictactoe @user');
    if (opponent === ctx.sender) return ctx.reply('❌ You can\'t challenge yourself.');
    if (tttGames.has(ctx.from)) {
      return ctx.reply('⚠️ A game is already in progress in this chat. Use .tictactoe cancel to end it first.');
    }

    const game = { board: Array(9).fill(null), players: { X: ctx.sender, O: opponent }, turn: 'X' };
    tttGames.set(ctx.from, game);

    await ctx.sock.sendMessage(
      ctx.from,
      {
        text: `🎮 Tic Tac Toe started!\n\n@${ctx.sender.split('@')[0]} (❌) vs @${opponent.split('@')[0]} (⭕)\n\n${tttRenderBoard(game.board)}\n\n@${ctx.sender.split('@')[0]}'s turn (❌). Play with ${ctx.prefix}move <1-9>.`,
        mentions: [ctx.sender, opponent],
      },
      { quoted: ctx.msg }
    );
  },
};

const move = {
  name: 'move',
  aliases: ['mv'],
  category: 'fun',
  groupOnly: true,
  description: 'Make a move in the active Tic Tac Toe game.',
  usage: '.move <1-9>',
  example: '.move 5',
  execute: async (ctx) => {
    const game = tttGames.get(ctx.from);
    if (!game) return ctx.reply(`❌ No active Tic Tac Toe game here. Start one with ${ctx.prefix}tictactoe @user`);

    const symbol = game.players.X === ctx.sender ? 'X' : game.players.O === ctx.sender ? 'O' : null;
    if (!symbol) return ctx.reply('❌ You are not part of the game running in this chat.');
    if (symbol !== game.turn) return ctx.reply('⏳ Not your turn.');

    const pos = parseInt(ctx.args[0], 10);
    if (!pos || pos < 1 || pos > 9) return ctx.reply('Usage: .move <1-9>');
    if (game.board[pos - 1]) return ctx.reply('❌ That cell is already taken — pick another.');

    game.board[pos - 1] = symbol;
    const winnerSymbol = tttCheckWinner(game.board);

    if (winnerSymbol) {
      const winnerJid = game.players[winnerSymbol];
      tttGames.delete(ctx.from);
      return ctx.sock.sendMessage(
        ctx.from,
        { text: `${tttRenderBoard(game.board)}\n\n🏆 @${winnerJid.split('@')[0]} wins!`, mentions: [winnerJid] },
        { quoted: ctx.msg }
      );
    }

    if (game.board.every(Boolean)) {
      tttGames.delete(ctx.from);
      return ctx.sock.sendMessage(ctx.from, { text: `${tttRenderBoard(game.board)}\n\n🤝 It's a draw!` }, { quoted: ctx.msg });
    }

    game.turn = game.turn === 'X' ? 'O' : 'X';
    const nextJid = game.players[game.turn];
    await ctx.sock.sendMessage(
      ctx.from,
      {
        text: `${tttRenderBoard(game.board)}\n\n@${nextJid.split('@')[0]}'s turn (${game.turn === 'X' ? '❌' : '⭕'}). Play with ${ctx.prefix}move <1-9>.`,
        mentions: [nextJid],
      },
      { quoted: ctx.msg }
    );
  },
};

const animeme = {
  ...meme,
  name: 'animeme',
  description: 'Random anime-themed meme.',
  usage: '.animeme',
};

module.exports = [joke, quote, meme, animeme, pickupline, truth, dare, ship, guess, math, trivia, rps, wouldyourather, tictactoe, move];
