const config = require('../config');
const db = require('./database');

/** Normalize a JID to a bare number string, e.g. "233xxx@s.whatsapp.net" -> "233xxx" */
function jidToNumber(jid = '') {
  return jid.split('@')[0].split(':')[0];
}

function isOwner(senderJid) {
  const num = jidToNumber(senderJid);
  return config.OWNER_NUMBER && num === config.OWNER_NUMBER;
}

function isSudo(senderJid) {
  const list = db.get('sudo', { users: [] }).users || [];
  return list.includes(jidToNumber(senderJid));
}

function isOwnerOrSudo(senderJid) {
  return isOwner(senderJid) || isSudo(senderJid);
}

/** Given a Baileys groupMetadata object, check if a jid is an admin. */
function isGroupAdmin(groupMetadata, jid) {
  if (!groupMetadata || !groupMetadata.participants) return false;
  const p = groupMetadata.participants.find((x) => x.id === jid);
  return !!p && (p.admin === 'admin' || p.admin === 'superadmin');
}

/** Check if the bot itself is admin in the group (required for kick/promote/etc). */
function isBotAdmin(groupMetadata, botJid) {
  return isGroupAdmin(groupMetadata, botJid);
}

module.exports = {
  jidToNumber,
  isOwner,
  isSudo,
  isOwnerOrSudo,
  isGroupAdmin,
  isBotAdmin,
};
