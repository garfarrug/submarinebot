const db = require('../../utils/database');

function getGroupConfig(groupId) {
  return db.getPath('groups', groupId, { welcome: false, goodbye: false });
}

async function handleGroupParticipantsUpdate(sock, ev) {
  const { id: groupId, participants, action } = ev;
  const cfg = getGroupConfig(groupId);

  if (action === 'add' && cfg.welcome) {
    for (const p of participants) {
      await sock
        .sendMessage(groupId, { text: `👋 Welcome @${p.split('@')[0]} to the group!`, mentions: [p] })
        .catch(() => {});
    }
  }
  if (action === 'remove' && cfg.goodbye) {
    for (const p of participants) {
      await sock
        .sendMessage(groupId, { text: `👋 @${p.split('@')[0]} has left the group.`, mentions: [p] })
        .catch(() => {});
    }
  }
}

module.exports = { handleGroupParticipantsUpdate, getGroupConfig };
