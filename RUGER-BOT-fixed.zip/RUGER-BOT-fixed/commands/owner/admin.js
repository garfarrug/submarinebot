const fs = require('fs-extra');
const path = require('path');
const config = require('../../config');
const { getMediaBuffer } = require('../../utils/media');
const sessionContext = require('../../utils/sessionContext');

const broadcast = {
  name: 'broadcast',
  category: 'owner',
  ownerOnly: true,
  description: 'Send a message to all known chats.',
  usage: '.broadcast <message>',
  example: '.broadcast RUGER update available',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .broadcast <message>');
    const chats = ctx.sock.chats ? Object.keys(ctx.sock.chats) : [];
    let sent = 0;
    for (const jid of chats) {
      await ctx.sock.sendMessage(jid, { text: `📢 Broadcast:\n\n${ctx.fullArgs}` }).catch(() => {});
      sent++;
    }
    await ctx.reply(`Broadcast sent to ${sent} chat(s).`);
  },
};

const join = {
  name: 'join',
  category: 'owner',
  ownerOnly: true,
  description: 'Join a WhatsApp group via invite link.',
  usage: '.join <invite link>',
  execute: async (ctx) => {
    const link = ctx.args[0];
    if (!link) return ctx.reply('Usage: .join <invite link>');
    const code = link.split('https://chat.whatsapp.com/')[1];
    if (!code) return ctx.reply('❌ Invalid invite link.');
    try {
      await ctx.sock.groupAcceptInvite(code);
      await ctx.reply('✅ Joined the group.');
    } catch (e) {
      await ctx.reply(`❌ Could not join: ${e.message}`);
    }
  },
};

const leave = {
  name: 'leave',
  category: 'owner',
  ownerOnly: true,
  groupOnly: true,
  description: 'Leave the current group.',
  usage: '.leave',
  execute: async (ctx) => {
    await ctx.reply('Leaving group...');
    await ctx.sock.groupLeave(ctx.from);
  },
};

const setppbot = {
  name: 'setppbot',
  category: 'owner',
  ownerOnly: true,
  description: "Change the bot's profile picture (reply to an image).",
  usage: 'Reply to an image with .setppbot',
  execute: async (ctx) => {
    const media = await getMediaBuffer(ctx.msg, ctx.sock.logger);
    if (!media || media.type !== 'imageMessage') return ctx.reply('Reply to an image with .setppbot');
    await ctx.sock.updateProfilePicture(ctx.sock.user.id, media.buffer);
    await ctx.reply('✅ Profile picture updated.');
  },
};

const setbio = {
  name: 'setbio',
  category: 'owner',
  ownerOnly: true,
  description: "Change the bot's WhatsApp bio/description.",
  usage: '.setbio <text>',
  example: '.setbio RUGER BOT ONLINE',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .setbio <text>');
    await ctx.sock.updateProfileStatus(ctx.fullArgs);
    await ctx.reply('✅ Bio updated.');
  },
};

const clearsession = {
  name: 'clearsession',
  aliases: ['delsession'],
  category: 'owner',
  ownerOnly: true,
  description: 'Delete the saved login session (requires re-pairing on next boot).',
  usage: '.clearsession',
  execute: async (ctx) => {
    const store = sessionContext.getStore();
    if (store && store.sessionActions) {
      // Shared multi-tenant process: only clear this caller's own session.
      await ctx.reply('⚠️ Clearing your session — go back to the pairing site for a new code.');
      setTimeout(() => store.sessionActions.clearSession().catch(() => {}), 500);
      return;
    }
    await ctx.reply('⚠️ Clearing session and restarting — you will need to re-pair.');
    await fs.remove(path.resolve(config.SESSION_DIR)).catch(() => {});
    setTimeout(() => process.exit(0), 800);
  },
};

const PLUGIN_DIR = path.join(__dirname, '..', '..', 'plugins');

const plugins = {
  name: 'plugins',
  category: 'owner',
  ownerOnly: true,
  description: 'Show installed plugins.',
  usage: '.plugins',
  execute: async (ctx) => {
    await fs.ensureDir(PLUGIN_DIR);
    const files = (await fs.readdir(PLUGIN_DIR)).filter((f) => f.endsWith('.js'));
    await ctx.reply(files.length ? `Installed plugins:\n${files.join('\n')}` : 'No plugins installed.\n\nDrop a .js command module into /plugins to install one, or use .install <path>.');
  },
};

const plugin = {
  name: 'plugin',
  category: 'owner',
  ownerOnly: true,
  description: 'Manage plugins (install/remove).',
  usage: '.plugin install <path> | .plugin remove <name>',
  execute: async (ctx) => {
    const [action, target] = ctx.args;
    if (action === 'install') return install.execute(ctx);
    if (action === 'remove') return uninstall.execute(ctx);
    await ctx.reply('Usage: .plugin install <path> | .plugin remove <name>');
  },
};

const install = {
  name: 'install',
  category: 'owner',
  ownerOnly: true,
  description: 'Install a plugin by copying a local .js command module into /plugins.',
  usage: '.install <local-file-path>',
  execute: async (ctx) => {
    const src = ctx.args[0];
    if (!src) return ctx.reply('Usage: .install <local-file-path-to-a-.js-command-module>');
    if (!src.endsWith('.js')) return ctx.reply('❌ Plugins must be .js command modules.');
    await fs.ensureDir(PLUGIN_DIR);
    const dest = path.join(PLUGIN_DIR, path.basename(src));
    try {
      await fs.copy(src, dest);
      await ctx.reply(`✅ Installed plugin: ${path.basename(src)}\nRestart the bot with .restart to load it.`);
    } catch (e) {
      await ctx.reply(`❌ Install failed: ${e.message}`);
    }
  },
};

const uninstall = {
  name: 'uninstall',
  category: 'owner',
  ownerOnly: true,
  description: 'Remove an installed plugin.',
  usage: '.uninstall <plugin-file-name>',
  execute: async (ctx) => {
    const name = ctx.args[0];
    if (!name) return ctx.reply('Usage: .uninstall <plugin-file-name>');
    const target = path.join(PLUGIN_DIR, name);
    if (!(await fs.pathExists(target))) return ctx.reply('❌ Plugin not found.');
    await fs.remove(target);
    await ctx.reply(`✅ Removed plugin: ${name}\nRestart the bot with .restart to apply.`);
  },
};

module.exports = [broadcast, join, leave, setppbot, setbio, clearsession, plugins, plugin, install, uninstall];
