/**
 * Small bounded in-memory cache of recent group message text, keyed by
 * chat + message id. Used by the `.antidelete` feature (commands/group/extra.js
 * + the messages.upsert hook in botCore.js) to show what a deleted message
 * said before it was revoked.
 *
 * Deliberately scoped to groups only (see botCore.js) and text-only — not
 * persisted to disk, and capped per chat so a long-running bot in busy
 * groups can't leak memory. Content is only ever re-shown inside the same
 * group it came from, never sent anywhere else.
 */
const MAX_ENTRIES_PER_CHAT = 200;

const store = new Map(); // chatId -> Map(msgId -> { text, sender, time })

function set(chatId, msgId, data) {
  if (!chatId || !msgId) return;
  let chatMap = store.get(chatId);
  if (!chatMap) {
    chatMap = new Map();
    store.set(chatId, chatMap);
  }
  chatMap.set(msgId, { ...data, time: Date.now() });
  if (chatMap.size > MAX_ENTRIES_PER_CHAT) {
    const oldestKey = chatMap.keys().next().value;
    chatMap.delete(oldestKey);
  }
}

function get(chatId, msgId) {
  return store.get(chatId)?.get(msgId) || null;
}

module.exports = { set, get };
