const axios = require('axios');

const qrcode = {
  name: 'qrcode',
  aliases: ['qr'],
  category: 'utility',
  description: 'Generate a QR code image from text or a link.',
  usage: '.qrcode <text>',
  example: '.qrcode https://wa.me/2330000000',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .qrcode <text>');
    const url = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(ctx.fullArgs)}`;
    await ctx.sock.sendMessage(ctx.from, { image: { url }, caption: '🔳 QR code generated.' }, { quoted: ctx.msg });
  },
};

const currency = {
  name: 'currency',
  aliases: ['convert', 'exchange'],
  category: 'utility',
  description: 'Convert an amount from one currency to another.',
  usage: '.currency <amount> <from> <to>',
  example: '.currency 100 USD GHS',
  execute: async (ctx) => {
    const [amountStr, from, to] = ctx.args;
    const amount = parseFloat(amountStr);
    if (!amount || !from || !to) return ctx.reply('Usage: .currency <amount> <from> <to>');
    try {
      const res = await axios.get(`https://open.er-api.com/v6/latest/${from.toUpperCase()}`);
      const rate = res.data?.rates?.[to.toUpperCase()];
      if (!rate) return ctx.reply(`❌ No rate found for ${to.toUpperCase()}.`);
      const result = (amount * rate).toFixed(2);
      await ctx.reply(`💱 ${amount} ${from.toUpperCase()} = ${result} ${to.toUpperCase()}`);
    } catch (e) {
      await ctx.reply(`❌ Conversion failed: ${e.message}`);
    }
  },
};

const wiki = {
  name: 'wiki',
  aliases: ['wikipedia'],
  category: 'utility',
  description: 'Get a short Wikipedia summary for a topic.',
  usage: '.wiki <topic>',
  example: '.wiki Ghana',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .wiki <topic>');
    try {
      const res = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(ctx.fullArgs)}`);
      const extract = res.data.extract;
      if (!extract) return ctx.reply(`❌ No summary found for "${ctx.fullArgs}".`);
      const link = res.data.content_urls?.desktop?.page || '';
      await ctx.reply(`📖 ${res.data.title}\n\n${extract}${link ? `\n\n🔗 ${link}` : ''}`);
    } catch (e) {
      await ctx.reply(`❌ Could not find "${ctx.fullArgs}" on Wikipedia.`);
    }
  },
};

const define = {
  name: 'define',
  aliases: ['dictionary'],
  category: 'utility',
  description: 'Get the dictionary definition of an English word.',
  usage: '.define <word>',
  example: '.define ephemeral',
  execute: async (ctx) => {
    const word = ctx.args[0];
    if (!word) return ctx.reply('Usage: .define <word>');
    try {
      const res = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
      const entry = res.data[0];
      const meaning = entry.meanings?.[0];
      const def = meaning?.definitions?.[0];
      if (!def) return ctx.reply(`❌ No definition found for "${word}".`);
      await ctx.reply(
        `📚 ${entry.word} (${meaning.partOfSpeech})\n\n${def.definition}${def.example ? `\n\nExample:\n${def.example}` : ''}`
      );
    } catch (e) {
      await ctx.reply(`❌ No definition found for "${word}".`);
    }
  },
};

const jid = {
  name: 'jid',
  category: 'utility',
  description: 'Show the WhatsApp JID of this chat and of a mentioned/replied user.',
  usage: '.jid [@user]',
  execute: async (ctx) => {
    const target = ctx.mentionedJid?.[0] || ctx.msg.message?.extendedTextMessage?.contextInfo?.participant;
    let text = `Chat JID:\n${ctx.from}`;
    if (target) text += `\n\nUser JID:\n${target}`;
    await ctx.reply(text);
  },
};

const remind = {
  name: 'remind',
  aliases: ['reminder'],
  category: 'utility',
  description: 'Get a reminder message back after a number of minutes (in-memory — lost on restart).',
  usage: '.remind <minutes> <text>',
  example: '.remind 10 Check the oven',
  execute: async (ctx) => {
    const minutes = parseFloat(ctx.args[0]);
    const text = ctx.args.slice(1).join(' ');
    if (!minutes || minutes <= 0 || !text) return ctx.reply('Usage: .remind <minutes> <text>');
    if (minutes > 1440) return ctx.reply('❌ Max reminder time is 1440 minutes (24 hours).');
    await ctx.reply(`⏰ Reminder set for ${minutes} minute(s) from now.`);
    setTimeout(() => {
      ctx.sock.sendMessage(ctx.from, { text: `⏰ Reminder:\n\n${text}` }, { quoted: ctx.msg }).catch(() => {});
    }, minutes * 60 * 1000);
  },
};

module.exports = [qrcode, currency, wiki, define, jid, remind];
