/**
 * Multi-tenant session manager.
 *
 * Lets many different people each link their own WhatsApp number to this
 * one running bot process — every number gets its own isolated Baileys
 * connection, auth folder, and JSON database (via sessionContext.js /
 * database.js), so nobody's data or settings touch anyone else's.
 *
 * Safety notes:
 *  - A pairing code can only ever be *completed* by typing it into the
 *    WhatsApp app on the phone that owns that number. Requesting a code
 *    for a number you don't control cannot link that account to anything —
 *    at worst it shows the real owner an unwanted "Link a device?" prompt,
 *    which is why this module rate-limits repeat requests per number.
 *  - MAX_SESSIONS caps how many concurrent live connections this process
 *    will hold, since each one is a persistent socket + in-memory state.
 */
const path = require('path');
const fs = require('fs-extra');
const pino = require('pino');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  Browsers,
} = require('@whiskeysockets/baileys');

const logger = require('./logger');
const sessionContext = require('./sessionContext');
const { attachHandlers, handleSuccessfulConnection, getReconnectDelayMs, createFlapDetector, DisconnectReason } = require('./botCore');
const { loadCommands } = require('./commandLoader');

// Everything that must survive a redeploy/restart lives under one root, so
// a single mounted volume (see fly.toml.example) covers both. Point
// DATA_DIR at your volume's mount path in production.
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..');
const SESSIONS_ROOT = path.join(DATA_DIR, 'sessions');
const DB_ROOT = path.join(DATA_DIR, 'database', 'tenants');
const MAX_SESSIONS = parseInt(process.env.MAX_SESSIONS || '25', 10);
const PAIR_COOLDOWN_MS = parseInt(process.env.PAIR_COOLDOWN_MS || '60000', 10); // per-number

fs.ensureDirSync(SESSIONS_ROOT);
fs.ensureDirSync(DB_ROOT);

const commands = loadCommands(path.join(__dirname, '..', 'commands'));
const pluginDir = path.join(__dirname, '..', 'plugins');
fs.ensureDirSync(pluginDir);
for (const [name, cmd] of loadCommands(pluginDir)) commands.set(name, cmd);
logger.info(`[sessionManager] Loaded ${new Set(commands.values()).size} commands.`);

/** number -> { sock, status, code, codeExpiresAt, lastPairRequestAt, error } */
const sessions = new Map();

function sanitizeNumber(raw) {
  return String(raw || '').replace(/[^0-9]/g, '');
}

function isValidNumber(number) {
  // Loose E.164-ish check: 8-15 digits, country code included, no leading 0.
  return /^[1-9][0-9]{7,14}$/.test(number);
}

function sessionPaths(number) {
  return {
    sessionDir: path.join(SESSIONS_ROOT, number),
    dbDir: path.join(DB_ROOT, number),
  };
}

function getStatus(number) {
  const s = sessions.get(number);
  if (!s) return { status: 'none' };
  const { status, code, codeExpiresAt, error } = s;
  return { status, code: status === 'pairing' ? code : undefined, codeExpiresAt, error };
}

function activeCount() {
  let n = 0;
  for (const s of sessions.values()) {
    if (s.status === 'pairing' || s.status === 'connected') n++;
  }
  return n;
}

/**
 * Kick off (or resume) a session for `rawNumber` and return a pairing code.
 * Throws with a short, user-safe message on validation/capacity/cooldown errors.
 */
async function requestPairing(rawNumber) {
  const number = sanitizeNumber(rawNumber);
  if (!isValidNumber(number)) {
    throw new Error('Enter a valid WhatsApp number with country code, digits only (e.g. 2335XXXXXXXX).');
  }

  const existing = sessions.get(number);
  if (existing && existing.status === 'connected') {
    return { status: 'connected' };
  }
  if (existing && existing.status === 'pairing' && Date.now() - existing.lastPairRequestAt < PAIR_COOLDOWN_MS) {
    return { status: 'pairing', code: existing.code, codeExpiresAt: existing.codeExpiresAt };
  }
  if (!existing && activeCount() >= MAX_SESSIONS) {
    throw new Error('This bot is at capacity right now — please try again later.');
  }

  return startSession(number);
}

async function startSession(number) {
  const { sessionDir, dbDir } = sessionPaths(number);
  fs.ensureDirSync(sessionDir);
  fs.ensureDirSync(dbDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    auth: state,
    // Browsers.ubuntu(name) returns ['Ubuntu', name, version] — `name` fills
    // the actual *browser* slot, not a free-text app label. The pairing-code
    // flow (unlike QR) validates that slot against a real, known browser, so
    // it must say 'Chrome' — passing our app name there ('RUGER BOT') made
    // WhatsApp reject the code as invalid when entered on the phone, even
    // though the code generated successfully server-side.
    browser: Browsers.ubuntu('Chrome'),
    // Prevents Baileys from timing out its own internal queries mid-handshake,
    // which otherwise can also surface as "Connection Closed" during pairing.
    defaultQueryTimeoutMs: undefined,
  });

  const store = {
    dbDir,
    config: { OWNER_NUMBER: number, SESSION_DIR: sessionDir },
    // Lets owner-only commands (.restart, .clearsession) act on just this
    // one session instead of process.exit()-ing the whole shared server.
    sessionActions: {
      restart: () => restartSession(number),
      clearSession: () => clearSession(number),
    },
  };
  const entry = sessions.get(number) || {};
  entry.sock = sock;
  entry.status = 'pairing';
  entry.lastPairRequestAt = Date.now();
  entry.error = undefined;
  entry.flapDetector = entry.flapDetector || createFlapDetector();
  sessions.set(number, entry);

  sock.ev.on('creds.update', saveCreds);

  // Resolves once we actually have something to tell the caller: a
  // pairing code, an already-open connection, or a failure. Guards against
  // requestPairing() racing the WebSocket handshake (the "Connection
  // Closed" / 428 bug) by only calling requestPairingCode() once Baileys
  // itself reports the socket is connecting (or has emitted a qr event) —
  // per Baileys' own docs, not immediately after makeWASocket().
  let settled = false;
  let resolveStart;
  const started = new Promise((resolve) => {
    resolveStart = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
  });
  const startTimeout = setTimeout(
    () => resolveStart({ status: 'error', error: 'Timed out waiting for a connection. Please try again.' }),
    25000
  );

  let pairingRequested = false;

  attachHandlers(sock, commands, {
    onConnectionUpdate: async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (
        !pairingRequested &&
        !sock.authState.creds.registered &&
        (connection === 'connecting' || qr)
      ) {
        pairingRequested = true;
        try {
          // Even once Baileys reports "connecting" / emits a qr, the noise
          // handshake with WhatsApp's servers can still be settling for a
          // moment longer. Calling requestPairingCode() too eagerly here is
          // the other common cause of "Connection Closed" (428) errors.
          await new Promise((r) => setTimeout(r, 2500));
          const code = await sock.requestPairingCode(number);
          entry.code = code;
          entry.codeExpiresAt = Date.now() + 2 * 60 * 1000; // WhatsApp codes expire quickly
          clearTimeout(startTimeout);
          resolveStart({ status: 'pairing', code, codeExpiresAt: entry.codeExpiresAt });
        } catch (err) {
          const statusCode = err?.output?.statusCode;
          logger.error(
            `[${number}] Failed to request pairing code (status ${statusCode || 'n/a'}):`,
            err.message || err
          );
          entry.status = 'error';
          entry.error = 'Could not generate a pairing code. Please try again.';
          clearTimeout(startTimeout);
          resolveStart({ status: 'error', error: entry.error });
        }
      }

      if (connection === 'close') {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
        const cur = sessions.get(number);
        const stillWaitingOnUnenteredCode =
          !sock.authState.creds.registered && !!cur?.code;

        // Always log the raw reason — without this, every failure during
        // pairing looks identical from the logs and there's no way to tell
        // "code expired", "IP flagged / connection refused", and "protocol
        // version rejected" apart.
        logger.warn(
          `[${number}] Connection closed. statusCode=${statusCode ?? 'n/a'} reason=${DisconnectReason[statusCode] || 'unknown'} message=${lastDisconnect?.error?.message || 'n/a'}`
        );

        if (shouldReconnect && stillWaitingOnUnenteredCode) {
          // A pairing code is bound to the socket/noise-handshake that
          // requested it. Silently opening a new socket here would request
          // a brand new code behind the scenes while the page still shows
          // the old (now dead) one — that's what made codes "not pair"
          // even though they displayed fine. Surface it instead so the
          // person knows to request a fresh code.
          logger.warn(`[${number}] Connection dropped before the code was entered.`);
          if (cur) {
            cur.status = 'error';
            cur.error = 'Connection dropped before the code was entered. Please request a new code.';
            cur.code = undefined;
          }
        } else if (shouldReconnect) {
          const flapping = entry.flapDetector.onClose();
          if (flapping) {
            // The connection is opening and dying again within seconds,
            // repeatedly — reconnecting again right now would just repeat
            // the cycle indefinitely and hammer WhatsApp's servers, which
            // risks the account getting flagged/logged out for abusive
            // behavior. Stop and surface it instead of retrying blind.
            logger.error(
              `[${number}] Connection is flapping (opening then closing repeatedly within seconds). Stopping auto-reconnect — check the statusCode above and use .restart once the cause is fixed.`
            );
            if (cur) {
              cur.status = 'error';
              cur.error = 'Connection keeps dropping right after connecting. Auto-reconnect stopped to avoid spamming — please check server logs before requesting a new code.';
            }
          } else {
            entry.reconnectAttempts = (entry.reconnectAttempts || 0) + 1;
            const delay = getReconnectDelayMs(entry.reconnectAttempts - 1);
            logger.warn(`[${number}] Connection closed, reconnecting in ${delay}ms...`);
            if (cur) cur.status = 'pairing';
            setTimeout(() => {
              startSession(number).catch((err) => {
                logger.error(`[${number}] Reconnect failed:`, err);
                const c = sessions.get(number);
                if (c) {
                  c.status = 'error';
                  c.error = 'Connection failed. Please request a new pairing code.';
                }
              });
            }, delay);
          }
        } else {
          logger.warn(`[${number}] Logged out.`);
          if (cur) cur.status = 'logged_out';
          fs.remove(sessionDir).catch(() => {});
        }
        clearTimeout(startTimeout);
        resolveStart({ status: cur?.status === 'logged_out' ? 'logged_out' : 'error', error: 'Connection closed.' });
      } else if (connection === 'open') {
        logger.success(`[${number}] Linked and online.`);
        entry.flapDetector.onOpen();
        const cur = sessions.get(number);
        if (cur) {
          cur.status = 'connected';
          cur.code = undefined;
          cur.reconnectAttempts = 0; // connection held — reset backoff
        }
        clearTimeout(startTimeout);
        resolveStart({ status: 'connected' });
        handleSuccessfulConnection(sock).catch((err) =>
          logger.error(`[${number}] handleSuccessfulConnection failed:`, err.message || err)
        );
      }
    },
  });

  // Wrap message/event handling for this socket so config.js and
  // database.js resolve to this session's own data automatically.
  const originalEmit = sock.ev.emit.bind(sock.ev);
  sock.ev.emit = (...args) => sessionContext.run(store, () => originalEmit(...args));

  return started;
}

/** Reconnect one session in place (used by the .restart command). */
async function restartSession(number) {
  const entry = sessions.get(number);
  if (entry && entry.sock) {
    try {
      entry.sock.end(new Error('restart requested'));
    } catch (_) {
      /* already closed */
    }
  }
  return startSession(number);
}

/** Log out and wipe one session's auth (used by the .clearsession command). */
async function clearSession(number) {
  const entry = sessions.get(number);
  if (entry && entry.sock) {
    try {
      await entry.sock.logout().catch(() => {});
    } catch (_) {
      /* ignore */
    }
    try {
      entry.sock.end(new Error('session cleared'));
    } catch (_) {
      /* ignore */
    }
  }
  const { sessionDir } = sessionPaths(number);
  await fs.remove(sessionDir).catch(() => {});
  sessions.delete(number);
}

module.exports = {
  requestPairing,
  getStatus,
  sanitizeNumber,
  isValidNumber,
  restartSession,
  clearSession,
  MAX_SESSIONS,
  activeCount,
};
