const { setSetting } = require('../../utils/settings');

function onOff(ctx) {
  const v = (ctx.args[0] || '').toLowerCase();
  if (v !== 'on' && v !== 'off') return null;
  return v === 'on';
}

const autoread = {
  name: 'autoread',
  category: 'owner',
  ownerOnly: true,
  description: 'Automatically read incoming messages.',
  usage: '.autoread on|off',
  execute: async (ctx) => {
    const v = onOff(ctx);
    if (v === null) return ctx.reply('Usage: .autoread on|off');
    setSetting('autoRead', v);
    await ctx.reply(`Auto read ${v ? 'enabled' : 'disabled'}.`);
  },
};

const autoviewstatus = {
  name: 'autoviewstatus',
  category: 'owner',
  ownerOnly: true,
  description: 'Automatically view WhatsApp statuses.',
  usage: '.autoviewstatus on|off',
  execute: async (ctx) => {
    const v = onOff(ctx);
    if (v === null) return ctx.reply('Usage: .autoviewstatus on|off');
    setSetting('autoViewStatus', v);
    await ctx.reply(`Status viewer ${v ? 'enabled' : 'disabled'}.`);
  },
};

const statusdelay = {
  name: 'statusdelay',
  category: 'owner',
  ownerOnly: true,
  description: 'Set delay (seconds) before auto-viewing a status.',
  usage: '.statusdelay <seconds>',
  example: '.statusdelay 10',
  execute: async (ctx) => {
    const n = parseInt(ctx.args[0], 10);
    if (Number.isNaN(n) || n < 0) return ctx.reply('Usage: .statusdelay <seconds>');
    setSetting('statusDelay', n);
    await ctx.reply(`Status delay set:\n${n} seconds`);
  },
};

const autolikestatus = {
  name: 'autolikestatus',
  aliases: ['autoreactstatus'],
  category: 'owner',
  ownerOnly: true,
  description: "Automatically react to contacts' status updates as the bot sees them.",
  usage: '.autolikestatus on|off',
  execute: async (ctx) => {
    const v = onOff(ctx);
    if (v === null) return ctx.reply('Usage: .autolikestatus on|off');
    setSetting('autoLikeStatus', v);
    await ctx.reply(`Auto-like status ${v ? 'enabled' : 'disabled'}.`);
  },
};

const setstatusemoji = {
  name: 'setstatusemoji',
  category: 'owner',
  ownerOnly: true,
  description: 'Choose the emoji used by .autolikestatus.',
  usage: '.setstatusemoji <emoji>',
  example: '.setstatusemoji 💚',
  execute: async (ctx) => {
    const emoji = ctx.args[0];
    if (!emoji) return ctx.reply('Usage: .setstatusemoji <emoji>');
    setSetting('statusLikeEmoji', emoji);
    await ctx.reply(`Status-like emoji set to:\n${emoji}`);
  },
};

const autoreact = {
  name: 'autoreact',
  category: 'owner',
  ownerOnly: true,
  description: 'Automatically react to incoming messages.',
  usage: '.autoreact on|off',
  execute: async (ctx) => {
    const v = onOff(ctx);
    if (v === null) return ctx.reply('Usage: .autoreact on|off');
    setSetting('autoReact', v);
    await ctx.reply(`Auto react ${v ? 'enabled' : 'disabled'}.`);
  },
};

const setreact = {
  name: 'setreact',
  category: 'owner',
  ownerOnly: true,
  description: 'Choose the emoji used by auto-react.',
  usage: '.setreact <emoji>',
  example: '.setreact ❤️',
  execute: async (ctx) => {
    const emoji = ctx.args[0];
    if (!emoji) return ctx.reply('Usage: .setreact <emoji>');
    setSetting('reactEmoji', emoji);
    await ctx.reply('Reaction changed.');
  },
};

const alwaysonline = {
  name: 'alwaysonline',
  category: 'owner',
  ownerOnly: true,
  description: 'Keep the bot showing as online.',
  usage: '.alwaysonline on|off',
  execute: async (ctx) => {
    const v = onOff(ctx);
    if (v === null) return ctx.reply('Usage: .alwaysonline on|off');
    setSetting('alwaysOnline', v);
    await ctx.reply(`Always online ${v ? 'enabled' : 'disabled'}.`);
  },
};

const autotype = {
  name: 'autotype',
  category: 'owner',
  ownerOnly: true,
  description: 'Automatically show typing status.',
  usage: '.autotype <group|chat|all|off>',
  execute: async (ctx) => {
    const valid = ['group', 'chat', 'all', 'off'];
    const v = (ctx.args[0] || '').toLowerCase();
    if (!valid.includes(v)) return ctx.reply(`Usage: .autotype <${valid.join('|')}>`);
    setSetting('autoType', v);
    await ctx.reply(`Auto type set to: ${v}`);
  },
};

const autorecord = {
  name: 'autorecord',
  category: 'owner',
  ownerOnly: true,
  description: 'Automatically show recording status.',
  usage: '.autorecord <group|chat|all|off>',
  execute: async (ctx) => {
    const valid = ['group', 'chat', 'all', 'off'];
    const v = (ctx.args[0] || '').toLowerCase();
    if (!valid.includes(v)) return ctx.reply(`Usage: .autorecord <${valid.join('|')}>`);
    setSetting('autoRecord', v);
    await ctx.reply(`Auto record set to: ${v}`);
  },
};

const antiviewonce = {
  name: 'antiviewonce',
  category: 'owner',
  ownerOnly: true,
  description:
    "Automatically reopen view-once photos/videos/voice notes/stickers that YOU send from your own account, forwarding a normal re-viewable copy to your own DM. Scoped to your own outgoing messages only — it never touches view-once content other people send you or the group (use .vv for that, one message at a time).",
  usage: '.antiviewonce all|group|chat|off',
  example: '.antiviewonce all',
  execute: async (ctx) => {
    const valid = ['all', 'group', 'chat', 'off'];
    const v = (ctx.args[0] || '').toLowerCase();
    if (!valid.includes(v)) {
      return ctx.reply(
        `Usage: .antiviewonce <${valid.join('|')}>\n\nNote: this only ever reopens view-once media that YOU send from this account (all = everywhere, group = only in groups, chat = only in DMs). It never captures view-once messages other people send you.`
      );
    }
    setSetting('antiViewOnce', v);
    await ctx.reply(`Antiviewonce (self-sent only) set to: ${v}`);
  },
};

module.exports = [
  autoread,
  autoviewstatus,
  statusdelay,
  autolikestatus,
  setstatusemoji,
  autoreact,
  setreact,
  alwaysonline,
  autotype,
  autorecord,
  antiviewonce,
];
