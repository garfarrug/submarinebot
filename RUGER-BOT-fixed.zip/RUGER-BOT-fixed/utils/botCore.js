/**
 * Shared connection + message-handling logic used by both:
 *  - index.js      (single personal bot, CLI pairing prompt)
 *  - sessionManager.js (many bots in one process, web pairing)
 *
 * Extracted from the original index.js so both modes behave identically
 * instead of maintaining two copies of the command dispatcher.
 */
const { downloadMediaMessage, DisconnectReason } = require('@whiskeysockets/baileys');
const config = require('../config');
const logger = require('./logger');
const { getSettings } = require('./settings');
const permissions = require('./permissions');
const db = require('./database');
const { runAntiChecks, getAntiConfig } = require('../commands/anti/_engine');
const { handleGroupParticipantsUpdate } = require('../commands/group/_welcome');
const statusCache = require('./statusCache');
const messageCache = require('./messageCache');
const afk = require('./afk');

/** Auto-read / auto-react / always-online / typing-recording presence */
async function handleAutomation(sock, msg) {
  const settings = getSettings();
  const from = msg.key.remoteJid;
  const isGroup = from.endsWith('@g.us');

  if (settings.autoRead) {
    await sock.readMessages([msg.key]).catch(() => {});
  }
  if (settings.autoReact) {
    await sock
      .sendMessage(from, { react: { text: settings.reactEmoji, key: msg.key } })
      .catch(() => {});
  }
  if (settings.alwaysOnline) {
    await sock.sendPresenceUpdate('available', from).catch(() => {});
  }

  const typeTarget = settings.autoType;
  if (typeTarget === 'all' || (typeTarget === 'group' && isGroup) || (typeTarget === 'chat' && !isGroup)) {
    await sock.sendPresenceUpdate('composing', from).catch(() => {});
  }
  const recTarget = settings.autoRecord;
  if (recTarget === 'all' || (recTarget === 'group' && isGroup) || (recTarget === 'chat' && !isGroup)) {
    await sock.sendPresenceUpdate('recording', from).catch(() => {});
  }
}

/**
 * Caches the last status update seen per contact (so `.getstatus` can hand
 * it back on request) and, if enabled, marks the status as viewed after
 * the configured delay. Does not touch anything the bot hasn't already
 * received as a normal status broadcast.
 */
async function handleStatusUpdate(sock, msg) {
  const participant = msg.key.participant || msg.participant;
  if (!participant || msg.key.fromMe) return;

  const m = msg.message;
  if (m.imageMessage || m.videoMessage) {
    try {
      const buffer = await downloadMediaMessage(msg, 'buffer', {}, { logger: sock.logger });
      statusCache.setStatus(participant, {
        kind: m.imageMessage ? 'image' : 'video',
        buffer,
        caption: m.imageMessage?.caption || m.videoMessage?.caption || '',
      });
    } catch (err) {
      logger.error('Failed to cache status media:', err);
    }
  } else {
    const text = m.conversation || m.extendedTextMessage?.text || '';
    if (text) statusCache.setStatus(participant, { kind: 'text', text });
  }

  const settings = getSettings();

  if (settings.autoLikeStatus) {
    await sock
      .sendMessage(
        'status@broadcast',
        { react: { text: settings.statusLikeEmoji || '💚', key: msg.key } },
        { statusJidList: [participant] }
      )
      .catch(() => {});
  }

  if (settings.autoViewStatus) {
    const delayMs = Math.max(0, settings.statusDelay || 0) * 1000;
    setTimeout(() => {
      sock.readMessages([msg.key]).catch(() => {});
    }, delayMs);
  }
}

function getMessageText(msg) {
  const m = msg.message;
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    ''
  );
}

/**
 * Detects a WhatsApp message-revocation event (someone deleted a message
 * they sent) and, if `.antidelete` is enabled for that group, re-posts the
 * cached text of what it said. Returns true if this event was a revocation
 * (whether or not anything was resent), so the caller can stop processing
 * it as a normal chat message.
 */
async function handleDeletionCheck(sock, msg) {
  const revoke = msg.message?.protocolMessage;
  if (!revoke || revoke.type !== 0) return false; // 0 = REVOKE
  const chatId = msg.key.remoteJid;
  if (!chatId?.endsWith('@g.us')) return true; // scoped to groups only, see messageCache.js
  try {
    const cfg = getAntiConfig(chatId);
    if (!cfg.antidelete?.enabled) return true;
    const cached = messageCache.get(chatId, revoke.key?.id);
    if (!cached) return true;
    const who = cached.sender ? `@${cached.sender.split('@')[0]}` : 'Someone';
    await sock.sendMessage(chatId, {
      text: `🗑️ *Deleted message detected*\n\nFrom: ${who}\n\nContent:\n${cached.text || '(non-text message — content was not cached)'}`,
      mentions: cached.sender ? [cached.sender] : [],
    });
  } catch (err) {
    logger.error('antidelete handler error:', err);
  }
  return true;
}

/**
 * Clears the sender's own AFK status once they send a message again, and
 * lets anyone who @mentions or replies to a currently-AFK user know.
 * Runs for every incoming message, independent of the command prefix.
 */
async function checkAfk(sock, msg) {
  const from = msg.key.remoteJid;
  const isGroup = from.endsWith('@g.us');
  const sender = isGroup ? msg.key.participant : from;
  if (!sender) return;

  const mine = afk.get(sender);
  if (mine) {
    afk.clear(sender);
    await sock
      .sendMessage(from, { text: `👋 Welcome back @${sender.split('@')[0]}, your AFK status has been cleared.`, mentions: [sender] }, { quoted: msg })
      .catch(() => {});
  }

  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
  const repliedTo = msg.message?.extendedTextMessage?.contextInfo?.participant;
  const targets = new Set([...mentioned, ...(repliedTo ? [repliedTo] : [])]);
  for (const target of targets) {
    if (target === sender) continue;
    const info = afk.get(target);
    if (!info) continue;
    const mins = Math.floor((Date.now() - info.since) / 60000);
    const ago = mins < 1 ? 'just now' : `${mins}m ago`;
    await sock
      .sendMessage(from, { text: `💤 @${target.split('@')[0]} is AFK (since ${ago})\nReason: ${info.reason}`, mentions: [target] }, { quoted: msg })
      .catch(() => {});
  }
}

/**
 * Unwraps a view-once envelope (WhatsApp wraps view-once photos/videos in
 * one of a few container types depending on client version).
 */
function unwrapViewOnce(message) {
  return (
    message?.viewOnceMessageV2?.message ||
    message?.viewOnceMessageV2Extension?.message ||
    message?.viewOnceMessage?.message ||
    null
  );
}

/**
 * `.antiviewonce` — deliberately scoped to the bot's OWN account only.
 * When the paired number sends a view-once photo/video/voice-note/sticker
 * (to a group, a DM, or itself), this reopens it and forwards a normal,
 * re-viewable copy to the owner's own DM. It never runs for `fromMe:
 * false` messages, i.e. it can never touch content someone else sent —
 * that would silently defeat view-once's guarantee for people who didn't
 * choose to share that way with a bot. See botCore.js call site.
 */
async function handleSelfViewOnce(sock, msg) {
  const unwrapped = unwrapViewOnce(msg.message);
  if (!unwrapped) return;

  const settings = getSettings();
  const scope = settings.antiViewOnce || 'off';
  if (scope === 'off') return;

  const isGroup = msg.key.remoteJid.endsWith('@g.us');
  if (scope === 'group' && !isGroup) return;
  if (scope === 'chat' && isGroup) return;

  const kind = unwrapped.imageMessage
    ? 'image'
    : unwrapped.videoMessage
    ? 'video'
    : unwrapped.audioMessage
    ? 'audio'
    : unwrapped.stickerMessage
    ? 'sticker'
    : null;
  if (!kind) return;

  try {
    const buffer = await downloadMediaMessage({ key: msg.key, message: unwrapped }, 'buffer', {}, { logger: sock.logger });
    const selfJid = sock.user.id.replace(/:.*@/, '@');
    const payload = { [kind]: buffer };
    if (kind === 'image' || kind === 'video') {
      payload.caption = unwrapped[`${kind}Message`]?.caption || '';
    }
    if (kind === 'audio') {
      payload.mimetype = unwrapped.audioMessage?.mimetype || 'audio/mp4';
      payload.ptt = !!unwrapped.audioMessage?.ptt;
    }
    await sock.sendMessage(selfJid, payload).catch(() => {});
  } catch (err) {
    logger.error('antiviewonce (self) error:', err);
  }
}

/**
 * Runs once per successful `connection === 'open'` event (fresh pairing OR
 * a reconnect after a drop — WhatsApp doesn't distinguish, and re-running
 * this each time is harmless/idempotent).
 *
 *  1. Sets the account's WhatsApp display name to "RUGER'S BOT" so every
 *     newly-paired number shows up under that name to its contacts.
 *  2. Sends "RUGER IS ACTIVE🫠🥶" to the owner's own chat (Note to Self)
 *     and pins it there for 7 days.
 *
 * Both steps are best-effort: a failure here must never take the socket
 * down, so every WhatsApp call is individually try/caught and logged.
 */
async function handleSuccessfulConnection(sock) {
  try {
    await sock.updateProfileName("RUGER'S BOT");
  } catch (err) {
    logger.error('Failed to set profile name:', err.message || err);
  }

  // Guards against a flapping connection (open → close → open in a tight
  // loop) re-sending this on every single reconnect. Persisted to disk
  // (not just in-memory) so it survives a process restart too — without
  // this, a bad network/host causing repeated reconnects turns into a
  // burst of identical self-messages, which looks like automated spam to
  // WhatsApp and risks the account getting flagged or logged out.
  const BANNER_COOLDOWN_MS = 6 * 60 * 60 * 1000; // 6 hours
  const state = db.get('connection', {});
  const now = Date.now();
  if (state.lastBannerAt && now - state.lastBannerAt < BANNER_COOLDOWN_MS) {
    return;
  }

  try {
    const selfJid = sock.user.id.replace(/:.*@/, '@');
    const sent = await sock.sendMessage(selfJid, { text: 'RUGER IS ACTIVE🫠🥶' });
    // Mark "sent" before attempting the pin so a crash/close between the
    // two calls still counts against the cooldown instead of retrying the
    // plain message again on the very next reconnect.
    state.lastBannerAt = now;
    db.setPath('connection', 'lastBannerAt', now);

    const SEVEN_DAYS_SECONDS = 7 * 24 * 60 * 60;
    // Pin support landed in Baileys 6.6+ as a `pin` message content key:
    // { pin: { type: 1 /* 0 = unpin */, time: <seconds>, key } }.
    await sock.sendMessage(selfJid, {
      pin: {
        type: 1,
        time: SEVEN_DAYS_SECONDS,
        key: sent.key,
      },
    });
  } catch (err) {
    // If this Baileys version/WhatsApp rejects the pin content shape, we
    // still want the plain message to have gone out above — only log here.
    logger.error('Failed to send/pin active banner:', err.message || err);
  }
}

async function handleMessage(sock, msg, commands) {
  const from = msg.key.remoteJid;
  const isGroup = from.endsWith('@g.us');
  // For a self-bot, `fromMe: true` means the paired owner sent this from
  // their own phone, in ANY chat (a DM with someone else, a group, etc) —
  // not just their own self-chat. `msg.key.remoteJid` there is the OTHER
  // party's JID (or the group's), not the owner's, so using it as `sender`
  // made isOwner()/isSudo() checks fail for fromMe commands sent anywhere
  // except the owner's chat with themselves. Fall back to the bot's own
  // linked JID whenever the message is fromMe.
  const sender = isGroup ? msg.key.participant : msg.key.fromMe ? sock.user.id : from;
  const text = getMessageText(msg).trim();
  const settings = getSettings();

  let groupMetadata = null;
  if (isGroup) {
    groupMetadata = await sock.groupMetadata(from).catch(() => null);
    // Run anti-abuse checks on every group text message, command or not
    await runAntiChecks(sock, msg, { groupMetadata, text }).catch((e) => logger.error('antiChecks', e));
  }

  const prefix = settings.prefix || config.PREFIX;
  if (!text.startsWith(prefix)) return;

  const body = text.slice(prefix.length).trim();
  const [cmdName, ...rest] = body.split(/\s+/);
  if (!cmdName) return;
  const args = rest;
  const command = commands.get(cmdName.toLowerCase());
  if (!command) return;

  // Bot mode gating
  if (settings.mode === 'private' && !permissions.isOwnerOrSudo(sender)) return;
  if (settings.mode === 'chat' && isGroup) return;
  if (settings.mode === 'group' && !isGroup) return;

  const senderIsAdmin = isGroup ? permissions.isGroupAdmin(groupMetadata, sender) : false;
  const botJid = sock.user.id.replace(/:.*@/, '@');
  const senderIsOwner = permissions.isOwner(sender);
  const senderIsSudo = permissions.isSudo(sender);

  // Maintenance mode: only owner/sudo can use the bot while it's on.
  if (settings.maintenance && !(senderIsOwner || senderIsSudo)) {
    await sock
      .sendMessage(from, { text: settings.maintenanceMessage || '🛠️ The bot is under maintenance right now. Please try again later.' }, { quoted: msg })
      .catch(() => {});
    return;
  }

  const ctx = {
    sock,
    msg,
    from,
    sender,
    isGroup,
    groupMetadata,
    text,
    args,
    fullArgs: args.join(' '),
    prefix,
    settings,
    isSenderAdmin: senderIsAdmin,
    isBotAdmin: isGroup ? permissions.isGroupAdmin(groupMetadata, botJid) : false,
    isOwner: senderIsOwner,
    isSudo: senderIsSudo,
    isOwnerOrSudo: senderIsOwner || senderIsSudo,
    mentionedJid: msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [],
    quoted: msg.message?.extendedTextMessage?.contextInfo?.quotedMessage || null,
    reply: (content) =>
      sock.sendMessage(from, typeof content === 'string' ? { text: content } : content, { quoted: msg }),
  };

  if (command.ownerOnly && !ctx.isOwnerOrSudo) {
    return ctx.reply('🚫 This command is restricted to the bot owner/sudo users.');
  }
  if (command.groupOnly && !isGroup) {
    return ctx.reply('🚫 This command only works inside groups.');
  }
  if (command.adminOnly && isGroup && !senderIsAdmin && !ctx.isOwnerOrSudo) {
    return ctx.reply('🚫 This command requires group admin permission.');
  }

  logger.cmd(`${cmdName} <- ${sender}`);
  try {
    await command.execute(ctx);
  } catch (err) {
    logger.error(`Command "${cmdName}" failed:`, err);
    await ctx.reply(`⚠️ Something went wrong running .${cmdName}:\n${err.message || err}`);
  }
}

/**
 * Wires all the event listeners a live socket needs onto `sock`.
 * `commands` is the shared command map. `onConnectionUpdate` is an
 * optional extra hook (used by sessionManager to track per-session
 * open/close/pairing state for the web UI).
 */
function attachHandlers(sock, commands, { onConnectionUpdate } = {}) {
  sock.ev.on('connection.update', (update) => {
    if (onConnectionUpdate) onConnectionUpdate(update);
  });

  sock.ev.on('group-participants.update', async (ev) => {
    try {
      await handleGroupParticipantsUpdate(sock, ev);
    } catch (err) {
      logger.error('group-participants.update handler error:', err);
    }
  });

  sock.ev.on('call', async (calls) => {
    try {
      const { getAntiConfig } = require('../commands/anti/_engine');
      const cfg = getAntiConfig('_global');
      if (!cfg.anticall?.enabled) return;
      for (const call of calls) {
        if (call.status !== 'offer') continue;
        await sock.rejectCall(call.id, call.from).catch(() => {});
        if (cfg.anticall.message) {
          await sock.sendMessage(call.from, { text: cfg.anticall.message }).catch(() => {});
        }
      }
    } catch (err) {
      logger.error('call handler error:', err);
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    const msg = messages[0];
    if (!msg?.message) return;

    try {
      if (await handleDeletionCheck(sock, msg)) return;
    } catch (err) {
      logger.error('Deletion check error:', err);
    }

    if (msg.key.remoteJid?.endsWith('@g.us')) {
      messageCache.set(msg.key.remoteJid, msg.key.id, {
        text: getMessageText(msg),
        sender: msg.key.participant || msg.key.remoteJid,
      });
    }

    try {
      await checkAfk(sock, msg);
    } catch (err) {
      logger.error('AFK check error:', err);
    }

    if (msg.key.remoteJid === 'status@broadcast') {
      try {
        await handleStatusUpdate(sock, msg);
      } catch (err) {
        logger.error('Status handler error:', err);
      }
      return;
    }

    if (msg.key.fromMe) {
      // This is a personal/self-bot: it's controlled by the paired number
      // texting commands (e.g. `.menu`) into any chat, including itself.
      // Automation like auto-read/auto-react doesn't make sense on your own
      // messages, but commands must still be dispatched — otherwise the
      // owner has no way to control their own bot.
      try {
        await handleSelfViewOnce(sock, msg);
      } catch (err) {
        logger.error('antiviewonce hook error:', err);
      }
      try {
        await handleMessage(sock, msg, commands);
      } catch (err) {
        logger.error('Handler error:', err);
      }
      return;
    }

    try {
      await handleAutomation(sock, msg);
      await handleMessage(sock, msg, commands);
    } catch (err) {
      logger.error('Handler error:', err);
    }
  });
}

/**
 * Backoff schedule for reconnect attempts. Immediately retrying a dropped
 * socket in a tight loop is itself a cause of *more* drops — WhatsApp reads
 * rapid reconnect churn from the same number as suspicious and can start
 * closing the socket faster/sooner. Capped, jittered exponential backoff
 * keeps the bot self-healing without hammering the server.
 */
function getReconnectDelayMs(attempt) {
  const base = Math.min(30000, 1000 * 2 ** Math.max(0, attempt)); // 1s,2s,4s...30s cap
  const jitter = Math.floor(Math.random() * 1000);
  return base + jitter;
}

/**
 * Detects a flapping connection: opens successfully, then closes again
 * within `windowMs`, repeatedly. Backoff alone doesn't catch this — the
 * connection reaching 'open' resets a naive retry counter, so a socket
 * that opens and immediately dies would otherwise retry forever at full
 * speed. That's exactly the pattern that spammed duplicate "connected"
 * banners (see handleSuccessfulConnection) and risks WhatsApp treating the
 * account as abusive. After `maxFlaps` quick open→close cycles in a row,
 * onClose() returns true and the caller should stop auto-reconnecting and
 * surface a clear error instead.
 */
function createFlapDetector({ windowMs = 20000, maxFlaps = 4 } = {}) {
  let openedAt = null;
  let flapCount = 0;
  return {
    onOpen() {
      openedAt = Date.now();
    },
    onClose() {
      if (openedAt && Date.now() - openedAt < windowMs) {
        flapCount += 1;
      } else {
        flapCount = 0;
      }
      openedAt = null;
      return flapCount >= maxFlaps;
    },
  };
}

module.exports = {
  attachHandlers,
  handleMessage,
  handleAutomation,
  handleStatusUpdate,
  handleSuccessfulConnection,
  getReconnectDelayMs,
  createFlapDetector,
  getMessageText,
  DisconnectReason,
};
