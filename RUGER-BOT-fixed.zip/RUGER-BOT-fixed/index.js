const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  Browsers,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const readline = require('readline');
const config = require('./config');
const logger = require('./utils/logger');
const { loadCommands } = require('./utils/commandLoader');
const { attachHandlers, handleSuccessfulConnection, getReconnectDelayMs, createFlapDetector, DisconnectReason } = require('./utils/botCore');

const path = require('path');
const fs = require('fs-extra');

// A bug in one command/plugin shouldn't kill the whole bot process.
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled promise rejection:', reason);
});
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception:', err);
});

const commands = loadCommands(path.join(__dirname, 'commands'));
const pluginDir = path.join(__dirname, 'plugins');
fs.ensureDirSync(pluginDir);
for (const [name, cmd] of loadCommands(pluginDir)) commands.set(name, cmd);
logger.info(`Loaded ${new Set(commands.values()).size} commands.`);

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (q) => new Promise((res) => rl.question(q, res));

// Persists across reconnects (module-scoped, not re-created per start() call)
// so it can actually detect a connection that keeps opening then dying.
const flapDetector = createFlapDetector();

async function start(reconnectAttempt = 0) {
  const { state, saveCreds } = await useMultiFileAuthState(config.SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: !config.USE_PAIRING_CODE,
    auth: state,
    // A custom/unrecognized browser triple makes WhatsApp's servers reject
    // the pairing handshake with "Connection Closed" (428).
    browser: Browsers.ubuntu('Chrome'),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on('creds.update', saveCreds);

  // Pairing code flow (no QR needed) if enabled and not yet registered.
  // IMPORTANT: requestPairingCode() must be called once the socket has
  // reached the "connecting" state (or emitted a qr event) — calling it
  // immediately after makeWASocket() races the WebSocket handshake and
  // throws "Connection Closed" (428). See connection.update below.
  let pairingRequested = false;

  attachHandlers(sock, commands, {
    onConnectionUpdate: async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (
        config.USE_PAIRING_CODE &&
        !pairingRequested &&
        !sock.authState.creds.registered &&
        (connection === 'connecting' || qr)
      ) {
        pairingRequested = true;
        const number = config.PAIR_NUMBER || (await question('Enter WhatsApp number for pairing (e.g. 233XXXXXXXXX): '));
        try {
          await new Promise((r) => setTimeout(r, 2500));
          const code = await sock.requestPairingCode(number.replace(/[^0-9]/g, ''));
          logger.success(`Pairing code: ${code}`);
        } catch (err) {
          logger.error('Failed to request pairing code:', err.message || err);
          pairingRequested = false; // allow a retry on the next connecting/qr event
        }
      }

      if (connection === 'close') {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
        logger.warn(
          `Connection closed. statusCode=${statusCode ?? 'n/a'} reason=${DisconnectReason[statusCode] || 'unknown'} message=${lastDisconnect?.error?.message || 'n/a'}`,
          shouldReconnect ? 'Reconnecting...' : 'Logged out.'
        );
        if (shouldReconnect) {
          const flapping = flapDetector.onClose();
          if (flapping) {
            logger.error(
              'Connection is flapping (opening then closing repeatedly within seconds). Stopping auto-reconnect — check the statusCode above, fix the cause, then restart the process.'
            );
            return;
          }
          const delay = getReconnectDelayMs(reconnectAttempt);
          setTimeout(() => start(reconnectAttempt + 1), delay);
        }
      } else if (connection === 'open') {
        reconnectAttempt = 0; // reset backoff once a connection actually holds
        flapDetector.onOpen();
        logger.success(`${config.BOT_NAME} is online.`);
        handleSuccessfulConnection(sock).catch((err) =>
          logger.error('handleSuccessfulConnection failed:', err.message || err)
        );
      }
    },
  });

  return sock;
}

start();

module.exports = { commands };
