const fs = require('fs-extra');
const path = require('path');
const config = require('../../config');
const { setSetting } = require('../../utils/settings');
const sessionContext = require('../../utils/sessionContext');

const setprefix = {
  name: 'setprefix',
  category: 'owner',
  ownerOnly: true,
  description: "Change the bot's command prefix.",
  usage: '.setprefix <symbol>',
  example: '.setprefix !',
  execute: async (ctx) => {
    const p = ctx.args[0];
    if (!p || p.length > 3) return ctx.reply('Usage: .setprefix <symbol>\n(1-3 characters, e.g. ! or #)');
    setSetting('prefix', p);
    await ctx.reply(`✅ Prefix changed to: ${p}\n\nExample: ${p}menu`);
  },
};

const setname = {
  name: 'setname',
  category: 'owner',
  ownerOnly: true,
  description: "Change the bot account's WhatsApp display name.",
  usage: '.setname <name>',
  example: '.setname RUGER BOT',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .setname <name>');
    try {
      await ctx.sock.updateProfileName(ctx.fullArgs);
      await ctx.reply(`✅ Display name updated to: ${ctx.fullArgs}`);
    } catch (e) {
      await ctx.reply(`❌ Could not update name: ${e.message}`);
    }
  },
};

const listblocked = {
  name: 'listblocked',
  aliases: ['blocklist'],
  category: 'owner',
  ownerOnly: true,
  description: 'Show all currently blocked contacts.',
  usage: '.listblocked',
  execute: async (ctx) => {
    try {
      const blocked = await ctx.sock.fetchBlocklist();
      if (!blocked?.length) return ctx.reply('No blocked contacts.');
      await ctx.reply(`🚫 BLOCKED CONTACTS (${blocked.length})\n\n${blocked.map((j) => j.split('@')[0]).join('\n')}`);
    } catch (e) {
      await ctx.reply(`❌ Could not fetch blocklist: ${e.message}`);
    }
  },
};

const maintenance = {
  name: 'maintenance',
  category: 'owner',
  ownerOnly: true,
  description: 'Toggle maintenance mode — while on, only owner/sudo can use any command.',
  usage: '.maintenance on|off [message]',
  example: '.maintenance on Doing an update, back soon!',
  execute: async (ctx) => {
    const v = (ctx.args[0] || '').toLowerCase();
    if (v !== 'on' && v !== 'off') return ctx.reply('Usage: .maintenance on|off [message]');
    setSetting('maintenance', v === 'on');
    const msg = ctx.args.slice(1).join(' ');
    if (v === 'on' && msg) setSetting('maintenanceMessage', msg);
    await ctx.reply(`Maintenance mode ${v === 'on' ? 'enabled' : 'disabled'}.`);
  },
};

const backup = {
  name: 'backup',
  category: 'owner',
  ownerOnly: true,
  description: "Send a copy of this bot's saved data (settings, warnings, groups, etc.) as a file.",
  usage: '.backup',
  execute: async (ctx) => {
    const store = sessionContext.getStore();
    const dbDir = (store && store.dbDir) || path.join(__dirname, '..', '..', 'database');
    if (!(await fs.pathExists(dbDir))) return ctx.reply('❌ No saved data found yet.');

    const files = (await fs.readdir(dbDir)).filter((f) => f.endsWith('.json'));
    if (!files.length) return ctx.reply('❌ No saved data found yet.');

    const combined = {};
    for (const f of files) {
      try {
        combined[f] = await fs.readJson(path.join(dbDir, f));
      } catch (_) {
        /* skip unreadable file */
      }
    }

    const buffer = Buffer.from(JSON.stringify(combined, null, 2));
    await ctx.sock.sendMessage(ctx.from, {
      document: buffer,
      fileName: `ruger-backup-${Date.now()}.json`,
      mimetype: 'application/json',
    });
  },
};

const stats = {
  name: 'stats',
  category: 'owner',
  ownerOnly: true,
  description: 'Show basic bot resource stats.',
  usage: '.stats',
  execute: async (ctx) => {
    const mem = process.memoryUsage();
    const mb = (n) => (n / 1024 / 1024).toFixed(1);
    await ctx.reply(
      `📊 BOT STATS\n\nMemory used:\n${mb(mem.heapUsed)} MB / ${mb(mem.heapTotal)} MB\n\nNode version:\n${process.version}\n\nPlatform:\n${process.platform}\n\nBot name:\n${config.BOT_NAME}`
    );
  },
};

module.exports = [setprefix, setname, listblocked, maintenance, backup, stats];
