const { generateForwardMessageContent, generateWAMessageFromContent } = require('@whiskeysockets/baileys');

async function forwardTo(sock, jid, quotedMsg) {
  const content = generateForwardMessageContent(quotedMsg, false);
  const waMsg = generateWAMessageFromContent(jid, content, {});
  await sock.relayMessage(jid, waMsg.message, { messageId: waMsg.key.id });
}

const forward = {
  name: 'forward',
  category: 'forward',
  description: 'Forward a message you replied to. Requires replying to the message first.',
  usage: '.forward <number> | .forward group | .forward allgroups | .forward allcontacts | .forward all',
  example: 'Reply to a message, then: .forward 233501234567',
  execute: async (ctx) => {
    const ctxInfo = ctx.msg.message?.extendedTextMessage?.contextInfo;
    const quoted = ctxInfo?.quotedMessage;
    if (!quoted) return ctx.reply('❌ Reply to the message you want to forward, then run .forward <target>.');

    const quotedFakeMsg = { key: { remoteJid: ctx.from, id: ctxInfo.stanzaId, fromMe: false, participant: ctxInfo.participant }, message: quoted };
    const target = (ctx.args[0] || '').toLowerCase();

    if (!target) return ctx.reply('Usage: .forward <number> | .forward group | .forward allgroups | .forward allcontacts | .forward all');

    if (target === 'group') {
      await forwardTo(ctx.sock, ctx.from, quotedFakeMsg);
      return ctx.reply('✅ Forwarded to this group.');
    }

    if (/^\d+$/.test(target)) {
      await forwardTo(ctx.sock, `${target}@s.whatsapp.net`, quotedFakeMsg);
      return ctx.reply(`✅ Forwarded to ${target}.`);
    }

    if (['allgroups', 'allcontacts', 'all'].includes(target)) {
      if (!ctx.isOwnerOrSudo) return ctx.reply('🚫 Bulk-forwarding is restricted to the owner/sudo.');
      const chats = ctx.sock.chats ? Object.keys(ctx.sock.chats) : [];
      const isGroupJid = (j) => j.endsWith('@g.us');
      const pool = chats.filter((j) =>
        target === 'allgroups' ? isGroupJid(j) : target === 'allcontacts' ? !isGroupJid(j) : true
      );
      let count = 0;
      for (const jid of pool) {
        await forwardTo(ctx.sock, jid, quotedFakeMsg).catch(() => {});
        count++;
      }
      return ctx.reply(`✅ Forwarded to ${count} chat(s).`);
    }

    await ctx.reply('❌ Unknown target. Usage: .forward <number> | .forward group | .forward allgroups | .forward allcontacts | .forward all');
  },
};

module.exports = [forward];
