const axios = require('axios');
const moment = require('moment-timezone');
const { evaluate } = require('mathjs');
const crypto = require('crypto');
const translate = require('translate-google');

const weather = {
  name: 'weather',
  category: 'utility',
  description: 'Show current weather information for a city.',
  usage: '.weather <city>',
  example: '.weather Accra',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .weather <city>');
    try {
      const geo = await axios.get('https://geocoding-api.open-meteo.com/v1/search', {
        params: { name: ctx.fullArgs, count: 1 },
      });
      const place = geo.data?.results?.[0];
      if (!place) return ctx.reply(`❌ Could not find "${ctx.fullArgs}".`);
      const wx = await axios.get('https://api.open-meteo.com/v1/forecast', {
        params: { latitude: place.latitude, longitude: place.longitude, current_weather: true },
      });
      const cw = wx.data.current_weather;
      await ctx.reply(
        `🌤️ Weather in ${place.name}, ${place.country}\n\nTemperature:\n${cw.temperature}°C\n\nWind Speed:\n${cw.windspeed} km/h\n\nUpdated:\n${cw.time}`
      );
    } catch (e) {
      await ctx.reply(`❌ Could not fetch weather: ${e.message}`);
    }
  },
};

const time = {
  name: 'time',
  category: 'utility',
  description: 'Show the current time for a country/timezone.',
  usage: '.time <country or timezone>',
  execute: async (ctx) => {
    const q = ctx.fullArgs || 'UTC';
    const zones = moment.tz.names().filter((z) => z.toLowerCase().includes(q.toLowerCase()));
    const zone = zones[0] || 'UTC';
    await ctx.reply(`🕒 Time in ${zone}:\n\n${moment().tz(zone).format('dddd, MMMM Do YYYY, h:mm:ss A')}`);
  },
};

function calc(ctx) {
  if (!ctx.fullArgs) return ctx.reply(`Usage: ${ctx.prefix}calc 25*50`);
  try {
    const result = evaluate(ctx.fullArgs);
    return ctx.reply(`🧮 ${ctx.fullArgs} = ${result}`);
  } catch (e) {
    return ctx.reply(`❌ Invalid expression: ${e.message}`);
  }
}

const calculate = { name: 'calculate', category: 'utility', description: 'Solve a math expression.', usage: '.calculate 25*50', execute: calc };
const calcCmd = { name: 'calc', category: 'utility', description: 'Quick calculator.', usage: '.calc 100+50', execute: calc };

const genpass = {
  name: 'genpass',
  category: 'utility',
  description: 'Generate a secure random password.',
  usage: '.genpass <length>',
  example: '.genpass 12',
  execute: async (ctx) => {
    const len = Math.min(Math.max(parseInt(ctx.args[0], 10) || 12, 4), 64);
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    const pass = Array.from(crypto.randomFillSync(new Uint8Array(len)))
      .map((b) => chars[b % chars.length])
      .join('');
    await ctx.reply(`Generated Password:\n\n${pass}`);
  },
};

const tinyurl = {
  name: 'tinyurl',
  category: 'utility',
  description: 'Shorten a URL.',
  usage: '.tinyurl <link>',
  execute: async (ctx) => {
    const url = ctx.args[0];
    if (!url) return ctx.reply('Usage: .tinyurl <link>');
    try {
      const res = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
      await ctx.reply(`🔗 ${res.data}`);
    } catch (e) {
      await ctx.reply(`❌ Could not shorten that URL: ${e.message}`);
    }
  },
};

const translateCmd = {
  name: 'translate',
  category: 'utility',
  description: 'Translate text between languages.',
  usage: '.translate <from> <to> <text>',
  example: '.translate en fr Hello',
  execute: async (ctx) => {
    const [from, to, ...rest] = ctx.args;
    const text = rest.join(' ');
    if (!from || !to || !text) return ctx.reply('Usage: .translate <from> <to> <text>');
    try {
      const result = await translate(text, { from, to });
      await ctx.reply(`🌐 ${result}`);
    } catch (e) {
      await ctx.reply(`❌ Translation failed: ${e.message}`);
    }
  },
};

const tts = {
  name: 'tts',
  category: 'utility',
  description: 'Convert text to speech and send as a voice note.',
  usage: '.tts <text>',
  example: '.tts Hello world',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .tts <text>');
    const url = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&q=${encodeURIComponent(ctx.fullArgs)}`;
    await ctx.sock.sendMessage(ctx.from, { audio: { url }, mimetype: 'audio/mpeg', ptt: true }, { quoted: ctx.msg });
  },
};

const MORSE_MAP = {
  A: '.-', B: '-...', C: '-.-.', D: '-..', E: '.', F: '..-.', G: '--.', H: '....', I: '..', J: '.---',
  K: '-.-', L: '.-..', M: '--', N: '-.', O: '---', P: '.--.', Q: '--.-', R: '.-.', S: '...', T: '-',
  U: '..-', V: '...-', W: '.--', X: '-..-', Y: '-.--', Z: '--..',
  0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.',
  ' ': '/',
};

const morse = {
  name: 'morse',
  category: 'utility',
  description: 'Convert text to Morse code.',
  usage: '.morse <text>',
  example: '.morse SOS',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .morse <text>');
    const out = ctx.fullArgs
      .toUpperCase()
      .split('')
      .map((c) => MORSE_MAP[c] ?? c)
      .join(' ');
    await ctx.reply(out);
  },
};

const FANCY_MAP = {
  a: '𝓪', b: '𝓫', c: '𝓬', d: '𝓭', e: '𝓮', f: '𝓯', g: '𝓰', h: '𝓱', i: '𝓲', j: '𝓳', k: '𝓴', l: '𝓵',
  m: '𝓶', n: '𝓷', o: '𝓸', p: '𝓹', q: '𝓺', r: '𝓻', s: '𝓼', t: '𝓽', u: '𝓾', v: '𝓿', w: '𝔀', x: '𝔁', y: '𝔂', z: '𝔃',
};

function toFancy(text) {
  return text
    .split('')
    .map((c) => FANCY_MAP[c.toLowerCase()] || c)
    .join('');
}

const fancy = {
  name: 'fancy',
  category: 'utility',
  description: 'Convert text to fancy unicode font.',
  usage: '.fancy <text>',
  example: '.fancy RUGER',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .fancy <text>');
    await ctx.reply(toFancy(ctx.fullArgs));
  },
};

const write = {
  name: 'write',
  category: 'utility',
  description: 'Text formatting tools (bold/italic/fancy).',
  usage: '.write <text>',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .write <text>');
    await ctx.reply(`*Bold:* *${ctx.fullArgs}*\n_Italic:_ _${ctx.fullArgs}_\nFancy: ${toFancy(ctx.fullArgs)}`);
  },
};

module.exports = [weather, time, calculate, calcCmd, genpass, tinyurl, translateCmd, tts, morse, fancy, write];
