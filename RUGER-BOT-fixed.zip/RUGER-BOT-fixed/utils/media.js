const { downloadMediaMessage } = require('@whiskeysockets/baileys');

/**
 * Returns the message content object that holds media, checking the message
 * itself first, then a quoted/replied message.
 */
function extractMediaMessage(msg) {
  const m = msg.message;
  if (!m) return null;

  const direct =
    m.imageMessage ||
    m.videoMessage ||
    m.audioMessage ||
    m.stickerMessage ||
    m.documentMessage;
  if (direct) {
    return { message: m, type: Object.keys(m)[0] };
  }

  const ctx = m.extendedTextMessage?.contextInfo;
  const quoted = ctx?.quotedMessage;
  if (quoted) {
    const type = Object.keys(quoted).find((k) =>
      ['imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage', 'documentMessage'].includes(k)
    );
    if (type) return { message: quoted, type, isQuoted: true };
  }
  return null;
}

/** Download the media buffer for a message (direct or quoted). */
async function getMediaBuffer(msg, logger) {
  const found = extractMediaMessage(msg);
  if (!found) return null;
  const fakeMsg = found.isQuoted
    ? { key: msg.key, message: found.message }
    : msg;
  const buffer = await downloadMediaMessage(fakeMsg, 'buffer', {}, { logger });
  return { buffer, type: found.type };
}

module.exports = { extractMediaMessage, getMediaBuffer };
