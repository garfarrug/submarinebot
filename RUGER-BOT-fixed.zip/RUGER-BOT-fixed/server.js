/**
 * Public pairing site.
 *
 * Serves a one-page form where anyone can type a WhatsApp number and get
 * back an 8-character pairing code for their own bot session, hosted by
 * this same process. See utils/sessionManager.js for how sessions are
 * kept isolated from each other.
 *
 * Run with: npm run web
 */
try { require('dotenv').config(); } catch (_) { /* dotenv not installed locally is fine */ }

const path = require('path');
const express = require('express');
const logger = require('./utils/logger');
const sessionManager = require('./utils/sessionManager');

// This process can be hosting dozens of unrelated people's paired WhatsApp
// sessions at once (see sessionManager.js). Node kills the whole process on
// an unhandled promise rejection or uncaught exception by default — that
// would drop every one of those sessions over a bug in a single command or
// plugin. Log instead of exiting so one session's problem stays contained.
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled promise rejection:', reason);
});
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception:', err);
});

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- simple in-memory rate limiter (per IP) -------------------------------
// Keeps this endpoint from being used to spam pairing prompts at numbers
// that don't belong to the requester. Fine for a single-process deploy;
// swap for a shared store (e.g. Redis) if you ever run more than one.
const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000; // 10 minutes
const RATE_LIMIT_MAX = 5; // pairing requests per IP per window
const hits = new Map(); // ip -> [timestamps]

function rateLimited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < RATE_LIMIT_WINDOW_MS);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > RATE_LIMIT_MAX;
}

app.post('/api/pair', async (req, res) => {
  const ip = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress;

  if (rateLimited(ip)) {
    return res.status(429).json({ error: 'Too many pairing requests from this connection. Try again later.' });
  }

  const { number } = req.body || {};
  if (!number) {
    return res.status(400).json({ error: 'Missing WhatsApp number.' });
  }

  try {
    const result = await sessionManager.requestPairing(number);
    if (result.status === 'error' || result.status === 'logged_out') {
      return res.status(502).json({ error: result.error || 'Could not generate a pairing code. Please try again.' });
    }
    res.json(result);
  } catch (err) {
    logger.error('Pairing request failed:', err.message);
    res.status(400).json({ error: err.message || 'Could not generate a pairing code.' });
  }
});

app.get('/api/status/:number', (req, res) => {
  const number = sessionManager.sanitizeNumber(req.params.number);
  res.json(sessionManager.getStatus(number));
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true, activeSessions: sessionManager.activeCount(), maxSessions: sessionManager.MAX_SESSIONS });
});

app.listen(PORT, () => {
  logger.success(`Pairing site listening on port ${PORT}`);
});
