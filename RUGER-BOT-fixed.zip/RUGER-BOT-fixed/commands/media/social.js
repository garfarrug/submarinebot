const statusCache = require('../../utils/statusCache');

/** Figure out which user is being asked about: mention > reply > number arg > self. */
function resolveTargetJid(ctx) {
  if (ctx.mentionedJid?.length) return ctx.mentionedJid[0];
  const quotedParticipant = ctx.msg.message?.extendedTextMessage?.contextInfo?.participant;
  if (quotedParticipant) return quotedParticipant;
  if (ctx.args[0]) {
    const num = ctx.args[0].replace(/[^0-9]/g, '');
    if (num) return `${num}@s.whatsapp.net`;
  }
  return ctx.sender;
}

const getpp = {
  name: 'getpp',
  aliases: ['pp', 'profilepic', 'getpicture', 'getdp'],
  category: 'media',
  description: "Download a user's WhatsApp profile picture (self, @mention, replied user, or a number).",
  usage: '.getpp [@user | number]',
  example: '.getpp @John',
  execute: async (ctx) => {
    const target = resolveTargetJid(ctx);
    try {
      const url = await ctx.sock.profilePictureUrl(target, 'image');
      await ctx.sock.sendMessage(
        ctx.from,
        { image: { url }, caption: `📸 Profile picture:\n@${target.split('@')[0]}`, mentions: [target] },
        { quoted: ctx.msg }
      );
    } catch (e) {
      await ctx.reply('❌ Could not fetch that profile picture — it may be set to private, or the user has none.');
    }
  },
};

const getstatus = {
  name: 'getstatus',
  aliases: ['savestatus', 'statusdl', 'downloadstatus'],
  category: 'media',
  description:
    "Download a contact's most recent status update the bot has actually seen come through. Enable .autoviewstatus on so the bot starts seeing statuses.",
  usage: '.getstatus [@user | number]',
  example: '.getstatus @John',
  execute: async (ctx) => {
    const target = resolveTargetJid(ctx);
    const cached = statusCache.getStatus(target);
    if (!cached) {
      return ctx.reply(
        `❌ No recent status cached for @${target.split('@')[0]}.\n\nThe bot can only hand back a status it has actually seen. Turn on ${ctx.prefix}autoviewstatus on and try again after their next status update.`
      );
    }
    if (cached.kind === 'text') {
      return ctx.reply(`📝 Status text — @${target.split('@')[0]}:\n\n${cached.text}`);
    }
    const content =
      cached.kind === 'video'
        ? { video: cached.buffer, caption: cached.caption || `Status — @${target.split('@')[0]}` }
        : { image: cached.buffer, caption: cached.caption || `Status — @${target.split('@')[0]}` };
    await ctx.sock.sendMessage(ctx.from, content, { quoted: ctx.msg });
  },
};

module.exports = [getpp, getstatus];
