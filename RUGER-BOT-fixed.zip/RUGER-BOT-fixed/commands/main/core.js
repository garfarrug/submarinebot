const config = require('../../config');
const { getSettings } = require('../../utils/settings');
const sessionContext = require('../../utils/sessionContext');

const startTime = Date.now();

function formatRuntime(ms) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h} Hours\n${m} Minutes\n${sec} Seconds`;
}

/** Display metadata + fixed ordering for each command category. */
const CATEGORY_META = {
  main: { emoji: '🏠', title: 'Main' },
  group: { emoji: '👥', title: 'Group' },
  anti: { emoji: '🛡️', title: 'Security' },
  media: { emoji: '🎬', title: 'Media & Downloads' },
  download: { emoji: '📥', title: 'Downloader' },
  utility: { emoji: '🛠️', title: 'Utility' },
  owner: { emoji: '👑', title: 'Owner' },
  private: { emoji: '🔒', title: 'Private' },
  fun: { emoji: '🎉', title: 'Fun & Games' },
  forward: { emoji: '↪️', title: 'Forward' },
};
const CATEGORY_ORDER = ['main', 'group', 'anti', 'media', 'download', 'utility', 'private', 'owner', 'fun', 'forward'];

const menu = {
  name: 'menu',
  aliases: ['allmenu'],
  category: 'main',
  description: 'Display the complete RUGER BOT menu.',
  usage: '.menu',
  execute: async (ctx) => {
    const p = ctx.prefix;
    // Pulled live from the loaded command registry, so the menu can never
    // drift out of sync with what's actually installed/loaded.
    const { commands } = require('../../index');

    const seen = new Set();
    const byCategory = {};
    for (const cmd of commands.values()) {
      if (seen.has(cmd)) continue;
      seen.add(cmd);
      const cat = cmd.category || 'misc';
      (byCategory[cat] ||= []).push(cmd.name);
    }

    const order = [...CATEGORY_ORDER, ...Object.keys(byCategory).filter((c) => !CATEGORY_ORDER.includes(c))];

    let body = '';
    for (const cat of order) {
      const names = byCategory[cat];
      if (!names || !names.length) continue;
      const meta = CATEGORY_META[cat] || { emoji: '📂', title: cat.charAt(0).toUpperCase() + cat.slice(1) };
      body += `\n┌─「 ${meta.emoji}  ${meta.title.toUpperCase()} 」\n│ ${names.map((n) => `${p}${n}`).join('  ')}\n└──────────────────\n`;
    }

    const text = `╭━━━━━━━━━━━━━━━━━━╮\n┃   🤖  ${config.BOT_NAME} BOT   ┃\n╰━━━━━━━━━━━━━━━━━━╯\n\nPrefix: ${p}\nTotal Commands: ${seen.size}\n${body}\nType ${p}help <command> for details on any command.`;
    await ctx.reply(text);
  },
};

const help = {
  name: 'help',
  aliases: ['h'],
  category: 'main',
  description: 'Show command information.',
  usage: '.help <command>',
  execute: async (ctx) => {
    const commands = require('../../index').commands;
    if (!ctx.args[0]) {
      return ctx.reply(`Use ${ctx.prefix}menu to see all commands, or ${ctx.prefix}help <command> for details on one.`);
    }
    const name = ctx.args[0].toLowerCase().replace(ctx.prefix, '');
    const cmd = commands.get(name);
    if (!cmd) return ctx.reply(`❌ No command named "${name}" found.`);
    await ctx.reply(
      `╭━━━━━━━━━━━━━━╮\n┃ ${cmd.name.toUpperCase()} COMMAND ┃\n╰━━━━━━━━━━━━━━╯\n\nDescription:\n${cmd.description || 'No description.'}\n\nUsage:\n${cmd.usage || ctx.prefix + cmd.name}\n\nPermission:\n${cmd.ownerOnly ? 'Owner/Sudo' : cmd.adminOnly ? 'Group Admin' : 'Everyone'}${cmd.example ? `\n\nExample:\n${cmd.example}` : ''}`
    );
  },
};

const ping = {
  name: 'ping',
  category: 'main',
  description: 'Check bot response speed.',
  usage: '.ping',
  execute: async (ctx) => {
    const start = Date.now();
    const sent = await ctx.reply('🏓 Pong!');
    const ms = Date.now() - start;
    await ctx.sock.sendMessage(ctx.from, { text: `🏓 Pong!\n\nResponse:\n${ms}ms`, edit: sent.key }).catch(() => {});
  },
};

const alive = {
  name: 'alive',
  category: 'main',
  description: 'Check if the bot is online.',
  usage: '.alive',
  execute: async (ctx) => {
    await ctx.reply(`🤖 ${config.BOT_NAME} BOT\n\nStatus:\nOnline ✅\n\nSystem:\nActive`);
  },
};

const runtime = {
  name: 'runtime',
  aliases: ['uptime'],
  category: 'main',
  description: 'Show how long the bot has been running.',
  usage: '.runtime',
  execute: async (ctx) => {
    await ctx.reply(`⏱ Runtime:\n\n${formatRuntime(Date.now() - startTime)}`);
  },
};

const owner = {
  name: 'owner',
  category: 'main',
  description: 'Show official bot owner.',
  usage: '.owner',
  execute: async (ctx) => {
    await ctx.reply(`╭━━━━━━━━━━━━╮\n┃ BOT OWNER ┃\n╰━━━━━━━━━━━━╯\n\nOwner:\n${config.OWNER_USERNAME}`);
  },
};

const settingsCmd = {
  name: 'settings',
  category: 'main',
  description: 'Show current bot configuration.',
  usage: '.settings',
  execute: async (ctx) => {
    const s = getSettings();
    await ctx.reply(
      `Bot Mode:\n${s.mode}\n\nAuto Read:\n${s.autoRead ? 'ON' : 'OFF'}\n\nAlways Online:\n${s.alwaysOnline ? 'ON' : 'OFF'}\n\nAuto React:\n${s.autoReact ? 'ON' : 'OFF'}\n\nAuto Type:\n${s.autoType}\n\nAuto Record:\n${s.autoRecord}\n\nAuto View Status:\n${s.autoViewStatus ? 'ON' : 'OFF'}\n\nAuto Like Status:\n${s.autoLikeStatus ? `ON (${s.statusLikeEmoji})` : 'OFF'}`
    );
  },
};

const pair = {
  name: 'pair',
  category: 'main',
  ownerOnly: true,
  description: 'Generate a WhatsApp pairing code (see terminal on boot for the live flow).',
  usage: '.pair',
  execute: async (ctx) => {
    await ctx.reply('Pairing codes are issued on bot startup via the terminal — restart the bot and follow the prompt, or set PAIR_NUMBER in your environment.');
  },
};

const restart = {
  name: 'restart',
  category: 'main',
  ownerOnly: true,
  description: 'Restart the bot process safely.',
  usage: '.restart',
  execute: async (ctx) => {
    const store = sessionContext.getStore();
    if (store && store.sessionActions) {
      // Shared multi-tenant process: only reconnect this caller's own
      // session, never the whole server (that would drop everyone else).
      await ctx.reply('Restarting your session...\n\nPlease wait.');
      setTimeout(() => store.sessionActions.restart().catch(() => {}), 500);
      return;
    }
    await ctx.reply('Restarting system...\n\nPlease wait.');
    setTimeout(() => process.exit(0), 800); // process manager (pm2/systemd) should restart it
  },
};

module.exports = [menu, help, ping, alive, runtime, owner, settingsCmd, pair, restart];
