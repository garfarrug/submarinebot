const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const db = require('../../utils/database');
const afk = require('../../utils/afk');
const { getMediaBuffer } = require('../../utils/media');

function personalKey(prefixKey, jid) {
  return `${prefixKey}.${jid.replace(/[.@:]/g, '_')}`;
}

function unwrapViewOnce(message) {
  return (
    message?.viewOnceMessageV2?.message ||
    message?.viewOnceMessageV2Extension?.message ||
    message?.viewOnceMessage?.message ||
    message
  );
}

const afkCmd = {
  name: 'afk',
  category: 'private',
  description: "Mark yourself AFK. Anyone who @mentions or replies to you gets notified. Clears automatically the next time you message.",
  usage: '.afk [reason]',
  example: '.afk In a meeting',
  execute: async (ctx) => {
    afk.set(ctx.sender, ctx.fullArgs || 'AFK');
    await ctx.reply(
      `💤 You're now marked AFK.${ctx.fullArgs ? `\nReason: ${ctx.fullArgs}` : ''}\n\nThis clears automatically the next time you send a message.`
    );
  },
};

const note = {
  name: 'note',
  aliases: ['notes'],
  category: 'private',
  description: 'Save personal notes tied to your own number.',
  usage: '.note add <text> | .note list | .note del <#>',
  example: '.note add Buy groceries tomorrow',
  execute: async (ctx) => {
    const [action, ...rest] = ctx.args;
    const key = personalKey('notes', ctx.sender);
    const list = db.getPath('users', key, []);

    if (action === 'add') {
      const text = rest.join(' ');
      if (!text) return ctx.reply('Usage: .note add <text>');
      list.push({ text, time: Date.now() });
      db.setPath('users', key, list);
      return ctx.reply(`✅ Note saved (#${list.length}).`);
    }
    if (action === 'del' || action === 'delete') {
      const idx = parseInt(rest[0], 10) - 1;
      if (Number.isNaN(idx) || !list[idx]) return ctx.reply('Usage: .note del <#>');
      list.splice(idx, 1);
      db.setPath('users', key, list);
      return ctx.reply('✅ Note deleted.');
    }
    if (!list.length) return ctx.reply(`You have no saved notes.\n\nAdd one:\n${ctx.prefix}note add <text>`);
    await ctx.reply(`📝 YOUR NOTES\n\n${list.map((n, i) => `${i + 1}. ${n.text}`).join('\n')}`);
  },
};

const todo = {
  name: 'todo',
  category: 'private',
  description: 'Personal to-do list tied to your own number.',
  usage: '.todo add <task> | .todo list | .todo done <#> | .todo clear',
  example: '.todo add Finish the report',
  execute: async (ctx) => {
    const [action, ...rest] = ctx.args;
    const key = personalKey('todo', ctx.sender);
    const list = db.getPath('users', key, []);

    if (action === 'add') {
      const task = rest.join(' ');
      if (!task) return ctx.reply('Usage: .todo add <task>');
      list.push({ task, done: false });
      db.setPath('users', key, list);
      return ctx.reply(`✅ Added (#${list.length}).`);
    }
    if (action === 'done') {
      const idx = parseInt(rest[0], 10) - 1;
      if (Number.isNaN(idx) || !list[idx]) return ctx.reply('Usage: .todo done <#>');
      list[idx].done = true;
      db.setPath('users', key, list);
      return ctx.reply('✅ Marked done.');
    }
    if (action === 'clear') {
      db.setPath('users', key, []);
      return ctx.reply('✅ To-do list cleared.');
    }
    if (!list.length) return ctx.reply(`Your to-do list is empty.\n\nAdd one:\n${ctx.prefix}todo add <task>`);
    await ctx.reply(`✅ YOUR TO-DO LIST\n\n${list.map((t, i) => `${t.done ? '✔️' : '⬜'} ${i + 1}. ${t.task}`).join('\n')}`);
  },
};

const save = {
  name: 'save',
  category: 'private',
  description: 'Reply to a message with .save to have the bot resend it to your own DM.',
  usage: 'Reply to a message with .save',
  execute: async (ctx) => {
    if (!ctx.quoted) return ctx.reply('Reply to a message with .save to keep a copy of it.');
    const media = await getMediaBuffer(ctx.msg, ctx.sock.logger).catch(() => null);

    if (media) {
      const typeMap = {
        imageMessage: 'image',
        videoMessage: 'video',
        audioMessage: 'audio',
        documentMessage: 'document',
        stickerMessage: 'sticker',
      };
      const kind = typeMap[media.type] || 'document';
      const payload = { [kind]: media.buffer };
      if (kind === 'audio') payload.mimetype = 'audio/mp4';
      await ctx.sock.sendMessage(ctx.sender, payload).catch(() => {});
    } else {
      const text = ctx.quoted.conversation || ctx.quoted.extendedTextMessage?.text || '';
      if (!text) return ctx.reply('❌ Nothing saveable in that message.');
      await ctx.sock.sendMessage(ctx.sender, { text: `💾 Saved message:\n\n${text}` }).catch(() => {});
    }
    await ctx.reply('✅ Saved to your DM.');
  },
};

const vv = {
  name: 'vv',
  aliases: ['reveal'],
  category: 'private',
  description: 'Reply to a view-once photo/video with .vv to resend it as a normal, re-viewable message.',
  usage: 'Reply to a view-once message with .vv',
  execute: async (ctx) => {
    if (!ctx.quoted) return ctx.reply('Reply to a view-once photo/video with .vv');
    const unwrapped = unwrapViewOnce(ctx.quoted);
    const type = unwrapped.imageMessage ? 'imageMessage' : unwrapped.videoMessage ? 'videoMessage' : null;
    if (!type) return ctx.reply('❌ That reply is not a view-once photo/video.');

    const info = ctx.msg.message?.extendedTextMessage?.contextInfo;
    const fakeMsg = {
      key: { remoteJid: ctx.from, id: info?.stanzaId, participant: info?.participant },
      message: unwrapped,
    };
    try {
      const buffer = await downloadMediaMessage(fakeMsg, 'buffer', {}, { logger: ctx.sock.logger });
      const payload =
        type === 'imageMessage'
          ? { image: buffer, caption: unwrapped.imageMessage.caption || '' }
          : { video: buffer, caption: unwrapped.videoMessage.caption || '' };
      await ctx.sock.sendMessage(ctx.from, payload, { quoted: ctx.msg });
    } catch (e) {
      await ctx.reply(`❌ Could not open: ${e.message}`);
    }
  },
};

module.exports = [afkCmd, note, todo, save, vv];
