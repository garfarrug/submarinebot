const db = require('./database');
const config = require('../config');

function getSettings() {
  const stored = db.get('settings', {});
  return { ...config.DEFAULTS, ...stored };
}

function setSetting(key, value) {
  const stored = db.get('settings', { ...config.DEFAULTS });
  stored[key] = value;
  db.persist('settings');
  return stored;
}

module.exports = { getSettings, setSetting };
