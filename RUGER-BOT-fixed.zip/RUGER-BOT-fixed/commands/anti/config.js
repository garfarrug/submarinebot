const { getAntiConfig, setAntiConfig } = require('./_engine');

function statusLine(enabled) {
  return enabled ? '✅ enabled' : '❌ disabled';
}

function simpleToggle(name, key, description, usage) {
  return {
    name,
    category: 'anti',
    groupOnly: true,
    adminOnly: true,
    description,
    usage,
    execute: async (ctx) => {
      const v = (ctx.args[0] || '').toLowerCase();
      const cfg = getAntiConfig(ctx.from);
      if (v === 'on' || v === 'off') {
        cfg[key].enabled = v === 'on';
        setAntiConfig(ctx.from, cfg);
        return ctx.reply(`${name} ${cfg[key].enabled ? 'enabled' : 'disabled'}.`);
      }
      if (v === 'status') return ctx.reply(`${name}: ${statusLine(cfg[key].enabled)}`);
      return ctx.reply(`Usage: ${usage}`);
    },
  };
}

const antilink = {
  name: 'antilink',
  category: 'anti',
  groupOnly: true,
  adminOnly: true,
  description: 'Detect and remove unwanted links.',
  usage: '.antilink on|off|warn|kick',
  execute: async (ctx) => {
    const v = (ctx.args[0] || '').toLowerCase();
    const cfg = getAntiConfig(ctx.from);
    if (v === 'on') {
      cfg.antilink.enabled = true;
    } else if (v === 'off') {
      cfg.antilink.enabled = false;
    } else if (v === 'warn' || v === 'kick') {
      cfg.antilink.enabled = true;
      cfg.antilink.action = v;
    } else {
      return ctx.reply('Usage: .antilink on|off|warn|kick');
    }
    setAntiConfig(ctx.from, cfg);
    await ctx.reply(`Anti-link is now ${cfg.antilink.enabled ? 'ON' : 'OFF'} (action: ${cfg.antilink.action}).`);
  },
};

const antibot = simpleToggle('antibot', 'antibot', 'Detect unauthorized WhatsApp bot accounts in this group.', '.antibot on|off|status');
const antispam = simpleToggle('antispam', 'antispam', 'Prevent message flooding.', '.antispam on|off|status');
const antifake = simpleToggle('antifake', 'antifake', 'Detect suspicious/fake accounts.', '.antifake on|off|status');
const antitag = simpleToggle('antitag', 'antitag', 'Prevent excessive @mentions in one message.', '.antitag on|off|status');

const antibadword = {
  name: 'antibadword',
  category: 'anti',
  groupOnly: true,
  adminOnly: true,
  description: 'Filter prohibited words from group chat.',
  usage: '.antibadword on|off',
  execute: async (ctx) => {
    const v = (ctx.args[0] || '').toLowerCase();
    if (v !== 'on' && v !== 'off') return ctx.reply('Usage: .antibadword on|off');
    const cfg = getAntiConfig(ctx.from);
    cfg.antibadword.enabled = v === 'on';
    setAntiConfig(ctx.from, cfg);
    await ctx.reply(`Anti bad-word ${v === 'on' ? 'enabled' : 'disabled'}.`);
  },
};

const addbadword = {
  name: 'addbadword',
  category: 'anti',
  groupOnly: true,
  adminOnly: true,
  description: 'Add a word to the prohibited-words list.',
  usage: '.addbadword <word>',
  example: '.addbadword insult',
  execute: async (ctx) => {
    const word = ctx.args[0];
    if (!word) return ctx.reply('Usage: .addbadword <word>');
    const cfg = getAntiConfig(ctx.from);
    if (!cfg.antibadword.words.includes(word.toLowerCase())) cfg.antibadword.words.push(word.toLowerCase());
    setAntiConfig(ctx.from, cfg);
    await ctx.reply(`Added "${word}" to the filtered words list.`);
  },
};

const anticall = {
  name: 'anticall',
  category: 'anti',
  ownerOnly: true,
  description: 'Automatically reject and block WhatsApp calls to the bot.',
  usage: '.anticall on|off',
  execute: async (ctx) => {
    const v = (ctx.args[0] || '').toLowerCase();
    if (v !== 'on' && v !== 'off') return ctx.reply('Usage: .anticall on|off');
    const cfg = getAntiConfig('_global');
    cfg.anticall.enabled = v === 'on';
    setAntiConfig('_global', cfg);
    await ctx.reply(`Anti-call ${v === 'on' ? 'enabled' : 'disabled'}.`);
  },
};

const anticallmsg = {
  name: 'anticallmsg',
  category: 'anti',
  ownerOnly: true,
  description: 'Set the automatic reply sent to rejected callers.',
  usage: '.anticallmsg <text>',
  example: ".anticallmsg Sorry, I don't accept calls.",
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .anticallmsg <text>');
    const cfg = getAntiConfig('_global');
    cfg.anticall.message = ctx.fullArgs;
    setAntiConfig('_global', cfg);
    await ctx.reply('Call auto-response updated.');
  },
};

const groupantis = {
  name: 'groupantis',
  category: 'anti',
  groupOnly: true,
  description: 'Show all group security feature statuses.',
  usage: '.groupantis',
  execute: async (ctx) => {
    const cfg = getAntiConfig(ctx.from);
    const line = (label, enabled) => `${enabled ? '✅' : '❌'} ${label}`;
    await ctx.reply(
      `GROUP SECURITY\n\n${line('Anti Link', cfg.antilink.enabled)}\n${line('Anti Spam', cfg.antispam.enabled)}\n${line('Anti Bot', cfg.antibot.enabled)}\n${line('Anti Fake', cfg.antifake.enabled)}\n${line('Anti Bad Word', cfg.antibadword.enabled)}\n${line('Anti Tag', cfg.antitag.enabled)}`
    );
  },
};

module.exports = [antilink, antibot, antispam, antifake, antitag, antibadword, addbadword, anticall, anticallmsg, groupantis];
