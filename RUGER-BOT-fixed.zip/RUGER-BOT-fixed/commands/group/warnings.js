const db = require('../../utils/database');
const config = require('../../config');

function key(groupId, userJid) {
  return `${groupId}.${userJid.replace(/\./g, '_')}`;
}

function targetJid(ctx) {
  if (ctx.mentionedJid?.length) return ctx.mentionedJid[0];
  const q = ctx.msg.message?.extendedTextMessage?.contextInfo?.participant;
  return q || null;
}

const warn = {
  name: 'warn',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Warn a group member.',
  usage: '.warn @user <reason>',
  example: '.warn @John Spam',
  execute: async (ctx) => {
    const target = targetJid(ctx);
    if (!target) return ctx.reply('Usage: .warn @user <reason>');
    const reason = ctx.mentionedJid?.length ? ctx.args.slice(1).join(' ') : ctx.fullArgs;
    const list = db.getPath('warnings', key(ctx.from, target), []);
    list.push({ reason: reason || 'No reason given', time: Date.now(), by: ctx.sender });
    db.setPath('warnings', key(ctx.from, target), list);

    await ctx.reply(
      `Warning added.\n\nUser:\n@${target.split('@')[0]}\n\nReason:\n${reason || 'No reason given'}\n\nWarnings:\n${list.length}/${config.MAX_WARNINGS}`
    );

    if (list.length >= config.MAX_WARNINGS && ctx.isBotAdmin) {
      await ctx.sock.groupParticipantsUpdate(ctx.from, [target], 'remove').catch(() => {});
      await ctx.reply(`🚫 @${target.split('@')[0]} reached the warning limit and was removed.`);
      db.setPath('warnings', key(ctx.from, target), []);
    }
  },
};

const unwarn = {
  name: 'unwarn',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Remove the most recent warning from a user.',
  usage: '.unwarn @user',
  execute: async (ctx) => {
    const target = targetJid(ctx);
    if (!target) return ctx.reply('Usage: .unwarn @user');
    const list = db.getPath('warnings', key(ctx.from, target), []);
    if (!list.length) return ctx.reply('That user has no warnings.');
    list.pop();
    db.setPath('warnings', key(ctx.from, target), list);
    await ctx.reply(`Warning removed. Remaining: ${list.length}/${config.MAX_WARNINGS}`);
  },
};

const warnings = {
  name: 'warnings',
  category: 'group',
  groupOnly: true,
  description: 'Show a user\'s warnings.',
  usage: '.warnings @user',
  execute: async (ctx) => {
    const target = targetJid(ctx) || ctx.sender;
    const list = db.getPath('warnings', key(ctx.from, target), []);
    await ctx.reply(`Warnings:\n\nUser:\n@${target.split('@')[0]}\n\nTotal:\n${list.length}`);
  },
};

module.exports = [warn, unwarn, warnings];
