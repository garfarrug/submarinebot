/**
 * All platform downloaders are delegated to the maintained `btch-downloader`
 * package rather than hand-rolled scrapers, since third-party endpoints
 * change often and an unmaintained scraper silently breaks.
 *
 * Every function returns { ok: true, ...data } or { ok: false, error }
 * so command handlers never have to deal with raw exceptions.
 */
const { ttdl, igdl, fbdown, twitter, youtube, mediafire, yts } = require('btch-downloader');

async function safe(fn) {
  try {
    const data = await fn();
    if (data && data.status === false) {
      return { ok: false, error: data.msg || data.message || 'Request failed.' };
    }
    return { ok: true, data };
  } catch (err) {
    return { ok: false, error: err?.message || String(err) };
  }
}

const downloadTiktok = (url) => safe(() => ttdl(url));
const downloadInstagram = (url) => safe(() => igdl(url));
const downloadFacebook = (url) => safe(() => fbdown(url));
const downloadTwitter = (url) => safe(() => twitter(url));
const downloadMediafire = (url) => safe(() => mediafire(url));
const youtubeInfo = (url) => safe(() => youtube(url));

async function searchYoutube(query, limit = 5) {
  const res = await yts(query);
  const list = Array.isArray(res?.result) ? res.result : Array.isArray(res?.result?.videos) ? res.result.videos : [];
  return list.slice(0, limit).map((v) => ({
    title: v.title,
    url: v.url || v.link,
    duration: v.duration || v.timestamp,
    views: v.views,
    author: v.author?.name || v.channel,
    thumbnail: v.thumbnail || v.image,
  }));
}

module.exports = {
  downloadTiktok,
  downloadInstagram,
  downloadFacebook,
  downloadTwitter,
  downloadMediafire,
  youtubeInfo,
  searchYoutube,
};
