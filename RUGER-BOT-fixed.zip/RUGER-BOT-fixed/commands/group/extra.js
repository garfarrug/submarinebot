const db = require('../../utils/database');
const { getAntiConfig, setAntiConfig } = require('../anti/_engine');

function targetJid(ctx) {
  if (ctx.mentionedJid?.length) return ctx.mentionedJid[0];
  const q = ctx.msg.message?.extendedTextMessage?.contextInfo?.participant;
  return q || null;
}

const setrules = {
  name: 'setrules',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: "Set this group's rules.",
  usage: '.setrules <text>',
  example: '.setrules 1. Be respectful\\n2. No spam',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .setrules <text>');
    db.setPath('groups', `${ctx.from}.rules`, ctx.fullArgs);
    await ctx.reply('✅ Group rules updated.');
  },
};

const rules = {
  name: 'rules',
  category: 'group',
  groupOnly: true,
  description: "Show this group's rules.",
  usage: '.rules',
  execute: async (ctx) => {
    const text = db.getPath('groups', `${ctx.from}.rules`, null);
    if (!text) {
      return ctx.reply(`No rules have been set for this group yet.${ctx.isSenderAdmin ? `\n\nSet them with:\n${ctx.prefix}setrules <text>` : ''}`);
    }
    await ctx.reply(`📜 GROUP RULES\n\n${text}`);
  },
};

const listadmins = {
  name: 'listadmins',
  aliases: ['admins'],
  category: 'group',
  groupOnly: true,
  description: 'List all current group admins.',
  usage: '.listadmins',
  execute: async (ctx) => {
    const admins = ctx.groupMetadata.participants.filter((p) => p.admin);
    if (!admins.length) return ctx.reply('No admins found for this group.');
    await ctx.sock.sendMessage(
      ctx.from,
      {
        text: `👑 GROUP ADMINS (${admins.length})\n\n${admins.map((a) => `• @${a.id.split('@')[0]}${a.admin === 'superadmin' ? ' (owner)' : ''}`).join('\n')}`,
        mentions: admins.map((a) => a.id),
      },
      { quoted: ctx.msg }
    );
  },
};

const resetwarnings = {
  name: 'resetwarnings',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: "Clear a user's warning history entirely (not just the latest one).",
  usage: '.resetwarnings @user',
  execute: async (ctx) => {
    const target = targetJid(ctx);
    if (!target) return ctx.reply('Usage: .resetwarnings @user');
    const key = `${ctx.from}.${target.replace(/\./g, '_')}`;
    db.setPath('warnings', key, []);
    await ctx.reply({ text: `✅ Cleared all warnings for @${target.split('@')[0]}.`, mentions: [target] });
  },
};

const poll = {
  name: 'poll',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Create a poll. Separate the question and options with |.',
  usage: '.poll Question | Option1 | Option2 | ...',
  example: '.poll Best food? | Jollof | Waakye | Banku',
  execute: async (ctx) => {
    const parts = ctx.fullArgs.split('|').map((s) => s.trim()).filter(Boolean);
    if (parts.length < 3) {
      return ctx.reply('Usage: .poll Question | Option1 | Option2 | ...\n(need a question and at least 2 options)');
    }
    const [question, ...options] = parts;
    if (options.length > 12) return ctx.reply('❌ WhatsApp polls support a maximum of 12 options.');
    await ctx.sock.sendMessage(ctx.from, {
      poll: { name: question, values: options, selectableCount: 1 },
    });
  },
};

const antidelete = {
  name: 'antidelete',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Re-post a message in this group if someone deletes it (text only).',
  usage: '.antidelete on|off',
  execute: async (ctx) => {
    const v = (ctx.args[0] || '').toLowerCase();
    if (v !== 'on' && v !== 'off') return ctx.reply('Usage: .antidelete on|off');
    const cfg = getAntiConfig(ctx.from);
    cfg.antidelete = cfg.antidelete || {};
    cfg.antidelete.enabled = v === 'on';
    setAntiConfig(ctx.from, cfg);
    await ctx.reply(`Antidelete ${v === 'on' ? 'enabled' : 'disabled'} for this group.`);
  },
};

module.exports = [setrules, rules, listadmins, resetwarnings, poll, antidelete];
