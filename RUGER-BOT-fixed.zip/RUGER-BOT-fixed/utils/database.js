/**
 * Lightweight JSON-file database.
 * Not a real DB, but gives every command permanent, crash-safe storage
 * without adding an external dependency like Mongo/Postgres.
 *
 * In multi-tenant "pairing site" mode, each linked WhatsApp number gets
 * its own database directory (see utils/sessionManager.js) so warnings,
 * settings, sudo lists etc. never leak between different people's bots.
 * The active directory is resolved per-call from the async session
 * context; outside of a session (single-bot mode) it falls back to the
 * original global ./database folder.
 */
const fs = require('fs-extra');
const path = require('path');
const sessionContext = require('./sessionContext');

const DEFAULT_DB_DIR = path.join(__dirname, '..', 'database');

const FILES = {
  settings: 'settings.json',
  users: 'users.json',
  groups: 'groups.json',
  warnings: 'warnings.json',
  stats: 'stats.json',
  sudo: 'sudo.json',
  antidb: 'antidb.json', // toggles for antilink/antispam/antibot/antifake/antitag/antibadword/anticall
  connection: 'connection.json', // last-banner-sent timestamp etc — see handleSuccessfulConnection
};

// Cache is keyed by [dbDir][name] so concurrent sessions never share
// in-memory state even though they run in the same Node process.
const cache = {};

function currentDbDir() {
  const store = sessionContext.getStore();
  return (store && store.dbDir) || DEFAULT_DB_DIR;
}

function filePath(dbDir, name) {
  return path.join(dbDir, FILES[name]);
}

function ensureFile(dbDir, name, defaultValue) {
  fs.ensureDirSync(dbDir);
  const fp = filePath(dbDir, name);
  if (!fs.existsSync(fp)) {
    fs.writeJsonSync(fp, defaultValue, { spaces: 2 });
  }
}

function load(name, defaultValue = {}) {
  const dbDir = currentDbDir();
  cache[dbDir] = cache[dbDir] || {};
  if (cache[dbDir][name]) return cache[dbDir][name];
  ensureFile(dbDir, name, defaultValue);
  try {
    cache[dbDir][name] = fs.readJsonSync(filePath(dbDir, name));
  } catch (e) {
    cache[dbDir][name] = defaultValue;
  }
  return cache[dbDir][name];
}

function save(name) {
  const dbDir = currentDbDir();
  fs.ensureDirSync(dbDir);
  const tmp = filePath(dbDir, name) + '.tmp';
  fs.writeJsonSync(tmp, cache[dbDir][name], { spaces: 2 });
  fs.moveSync(tmp, filePath(dbDir, name), { overwrite: true });
}

/** Get the whole collection object (creates on first use). */
function get(name, defaultValue = {}) {
  return load(name, defaultValue);
}

/** Persist current in-memory state of a collection to disk. */
function persist(name) {
  save(name);
}

/** Get a nested value by dot path, e.g. get('groups', '123@g.us.warnings') */
function getPath(name, dotPath, fallback) {
  const obj = load(name);
  const parts = dotPath.split('.');
  let cur = obj;
  for (const p of parts) {
    if (cur == null || typeof cur !== 'object') return fallback;
    cur = cur[p];
  }
  return cur === undefined ? fallback : cur;
}

function setPath(name, dotPath, value) {
  const obj = load(name);
  const parts = dotPath.split('.');
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const p = parts[i];
    if (typeof cur[p] !== 'object' || cur[p] === null) cur[p] = {};
    cur = cur[p];
  }
  cur[parts[parts.length - 1]] = value;
  save(name);
  return value;
}

module.exports = { get, persist, getPath, setPath, FILES };
