/**
 * Small in-memory cache of the most recent status update the bot has
 * actually seen come through per contact, so `.getstatus` can hand it
 * back on request. Nothing is captured silently beyond what the bot
 * already receives as a normal status broadcast; this just remembers
 * the *last* one per contact instead of discarding it immediately.
 * Cleared on process restart (not persisted to disk).
 */
const cache = new Map(); // jid -> { kind: 'text'|'image'|'video', text?, buffer?, caption?, timestamp }

const MAX_AGE_MS = 24 * 60 * 60 * 1000; // WhatsApp statuses expire after 24h anyway

function setStatus(jid, data) {
  cache.set(jid, { ...data, timestamp: Date.now() });
}

function getStatus(jid) {
  const entry = cache.get(jid);
  if (!entry) return null;
  if (Date.now() - entry.timestamp > MAX_AGE_MS) {
    cache.delete(jid);
    return null;
  }
  return entry;
}

module.exports = { setStatus, getStatus };
