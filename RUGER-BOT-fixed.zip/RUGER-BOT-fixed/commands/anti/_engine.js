const config = require('../../config');
const db = require('../../utils/database');
const permissions = require('../../utils/permissions');

const LINK_REGEX = /(https?:\/\/|www\.|chat\.whatsapp\.com\/)[^\s]+/i;
const spamTracker = new Map(); // jid -> [timestamps]

function getAntiConfig(groupId) {
  return db.getPath('antidb', groupId, {
    antilink: { enabled: false, action: 'warn' },
    antispam: { enabled: false },
    antibot: { enabled: false },
    antifake: { enabled: false },
    antitag: { enabled: false },
    antibadword: { enabled: false, words: [] },
    anticall: { enabled: false, message: "Sorry, I don't accept calls." },
    antidelete: { enabled: false },
  });
}

function setAntiConfig(groupId, cfg) {
  db.setPath('antidb', groupId, cfg);
}

async function takeAction(sock, msg, groupMetadata, action, reason) {
  const from = msg.key.remoteJid;
  const sender = msg.key.participant;
  if (action === 'kick') {
    const botJid = sock.user.id.replace(/:.*@/, '@');
    if (permissions.isBotAdmin(groupMetadata, botJid)) {
      await sock.groupParticipantsUpdate(from, [sender], 'remove').catch(() => {});
    }
    await sock.sendMessage(from, { text: `🚫 @${sender.split('@')[0]} was removed: ${reason}`, mentions: [sender] });
  } else {
    await sock.sendMessage(from, { text: `⚠️ @${sender.split('@')[0]} — ${reason}`, mentions: [sender] });
  }
}

async function runAntiChecks(sock, msg, { groupMetadata, text }) {
  const from = msg.key.remoteJid;
  const sender = msg.key.participant;
  if (!sender || permissions.isGroupAdmin(groupMetadata, sender)) return; // never action admins/owner
  if (permissions.isOwnerOrSudo(sender)) return;

  const cfg = getAntiConfig(from);

  if (cfg.antilink?.enabled && LINK_REGEX.test(text)) {
    await sock.sendMessage(from, { delete: msg.key }).catch(() => {});
    await takeAction(sock, msg, groupMetadata, cfg.antilink.action === 'kick' ? 'kick' : 'warn', 'links are not allowed here.');
  }

  if (cfg.antibadword?.enabled && cfg.antibadword.words?.length) {
    const lower = text.toLowerCase();
    if (cfg.antibadword.words.some((w) => lower.includes(w.toLowerCase()))) {
      await sock.sendMessage(from, { delete: msg.key }).catch(() => {});
      await takeAction(sock, msg, groupMetadata, 'warn', 'that word is not allowed here.');
    }
  }

  if (cfg.antitag?.enabled) {
    const mentions = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (mentions.length > 5) {
      await takeAction(sock, msg, groupMetadata, 'warn', 'excessive tagging is not allowed.');
    }
  }

  if (cfg.antispam?.enabled) {
    const key = `${from}:${sender}`;
    const now = Date.now();
    const arr = (spamTracker.get(key) || []).filter((t) => now - t < config.ANTISPAM_WINDOW_MS);
    arr.push(now);
    spamTracker.set(key, arr);
    if (arr.length > config.ANTISPAM_MSG_LIMIT) {
      await takeAction(sock, msg, groupMetadata, 'warn', 'please slow down, spam detected.');
      spamTracker.set(key, []);
    }
  }
}

module.exports = { getAntiConfig, setAntiConfig, runAntiChecks };
