const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('ffmpeg-static');
const fs = require('fs-extra');
const os = require('os');
const path = require('path');
const { randomUUID } = require('crypto');

ffmpeg.setFfmpegPath(ffmpegPath);

function tmpFile(ext) {
  return path.join(os.tmpdir(), `ruger-${randomUUID()}.${ext}`);
}

function run(build) {
  return new Promise((resolve, reject) => {
    build
      .on('error', reject)
      .on('end', resolve)
      .run();
  });
}

/** Convert an image or short video buffer into a WhatsApp-ready animated/static webp sticker. */
async function toWebpSticker(buffer, { isVideo = false } = {}) {
  const inExt = isVideo ? 'mp4' : 'png';
  const inPath = tmpFile(inExt);
  const outPath = tmpFile('webp');
  await fs.writeFile(inPath, buffer);

  const cmd = ffmpeg(inPath).outputOptions([
    '-vcodec', 'libwebp',
    '-vf', "scale='min(512,iw)':min'(512,ih)':force_original_aspect_ratio=decrease,fps=15,pad=512:512:-1:-1:color=white@0.0,format=rgba",
    '-loop', '0',
    '-preset', 'default',
    '-an',
    '-vsync', '0',
    '-s', '512:512',
  ]).output(outPath);

  await run(cmd);
  const out = await fs.readFile(outPath);
  await fs.remove(inPath).catch(() => {});
  await fs.remove(outPath).catch(() => {});
  return out;
}

/** Convert a webp sticker back into a PNG image. */
async function webpToImage(buffer) {
  const inPath = tmpFile('webp');
  const outPath = tmpFile('png');
  await fs.writeFile(inPath, buffer);
  await run(ffmpeg(inPath).output(outPath));
  const out = await fs.readFile(outPath);
  await fs.remove(inPath).catch(() => {});
  await fs.remove(outPath).catch(() => {});
  return out;
}

/** Convert any audio/video buffer into an Opus voice-note (.ogg, codec opus). */
async function toVoiceNote(buffer, srcExt = 'mp3') {
  const inPath = tmpFile(srcExt);
  const outPath = tmpFile('ogg');
  await fs.writeFile(inPath, buffer);
  await run(
    ffmpeg(inPath)
      .outputOptions(['-avoid_negative_ts', 'make_zero', '-ac', '1', '-c:a', 'libopus', '-b:a', '64k', '-vn'])
      .output(outPath)
  );
  const out = await fs.readFile(outPath);
  await fs.remove(inPath).catch(() => {});
  await fs.remove(outPath).catch(() => {});
  return out;
}

/** Convert a voice note / any audio into a normal mp3 file. */
async function toMp3(buffer, srcExt = 'ogg') {
  const inPath = tmpFile(srcExt);
  const outPath = tmpFile('mp3');
  await fs.writeFile(inPath, buffer);
  await run(ffmpeg(inPath).output(outPath));
  const out = await fs.readFile(outPath);
  await fs.remove(inPath).catch(() => {});
  await fs.remove(outPath).catch(() => {});
  return out;
}

/** Convert a GIF (or any short clip) into an MP4 video. */
async function toMp4(buffer, srcExt = 'gif') {
  const inPath = tmpFile(srcExt);
  const outPath = tmpFile('mp4');
  await fs.writeFile(inPath, buffer);
  await run(
    ffmpeg(inPath)
      .outputOptions(['-movflags', 'faststart', '-pix_fmt', 'yuv420p', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2'])
      .output(outPath)
  );
  const out = await fs.readFile(outPath);
  await fs.remove(inPath).catch(() => {});
  await fs.remove(outPath).catch(() => {});
  return out;
}

module.exports = { toWebpSticker, webpToImage, toVoiceNote, toMp3, toMp4 };
