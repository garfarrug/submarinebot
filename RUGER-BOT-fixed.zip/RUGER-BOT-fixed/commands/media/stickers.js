const { getMediaBuffer } = require('../../utils/media');
const ff = require('../../utils/ffmpeg');
const { setSetting } = require('../../utils/settings');

const sticker = {
  name: 'sticker',
  aliases: ['tosticker', 's'],
  category: 'media',
  description: 'Convert a replied image/video into a sticker.',
  usage: 'Reply to an image/video with .sticker',
  execute: async (ctx) => {
    const media = await getMediaBuffer(ctx.msg, ctx.sock.logger);
    if (!media) return ctx.reply('Reply to an image or short video with .sticker');
    const isVideo = media.type === 'videoMessage';
    const webp = await ff.toWebpSticker(media.buffer, { isVideo });
    await ctx.sock.sendMessage(ctx.from, { sticker: webp }, { quoted: ctx.msg });
  },
};

const take = {
  name: 'take',
  category: 'media',
  description: 'Re-tag a sticker with a new pack/author name (reply to a sticker).',
  usage: '.take <pack name>',
  example: '.take RUGER BOT',
  execute: async (ctx) => {
    const media = await getMediaBuffer(ctx.msg, ctx.sock.logger);
    if (!media || media.type !== 'stickerMessage') return ctx.reply('Reply to a sticker with .take <name>');
    if (!ctx.fullArgs) return ctx.reply('Usage: .take <pack name>');
    await ctx.sock.sendMessage(ctx.from, { sticker: media.buffer, packname: ctx.fullArgs, author: 'RUGER BOT' }, { quoted: ctx.msg });
  },
};

const toimg = {
  name: 'toimg',
  aliases: ['toimage'],
  category: 'media',
  description: 'Convert a sticker back into an image.',
  usage: 'Reply to a sticker with .toimg',
  execute: async (ctx) => {
    const media = await getMediaBuffer(ctx.msg, ctx.sock.logger);
    if (!media || media.type !== 'stickerMessage') return ctx.reply('Reply to a sticker with .toimg');
    const png = await ff.webpToImage(media.buffer);
    await ctx.sock.sendMessage(ctx.from, { image: png }, { quoted: ctx.msg });
  },
};

const setstickername = {
  name: 'setstickername',
  category: 'media',
  ownerOnly: true,
  description: 'Set the default sticker author name used by .sticker.',
  usage: '.setstickername <name>',
  example: '.setstickername RUGER BOT',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .setstickername <name>');
    setSetting('stickerAuthor', ctx.fullArgs);
    await ctx.reply(`Created stickers now show:\n\n${ctx.fullArgs}`);
  },
};

const setwatermark = {
  name: 'setwatermark',
  category: 'media',
  ownerOnly: true,
  description: 'Set a text watermark for created media.',
  usage: '.setwatermark <text>',
  example: '.setwatermark RUGER',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .setwatermark <text>');
    setSetting('watermark', ctx.fullArgs);
    await ctx.reply(`Images/videos/stickers will reference:\n\n${ctx.fullArgs}`);
  },
};

module.exports = [sticker, take, toimg, setstickername, setwatermark];
