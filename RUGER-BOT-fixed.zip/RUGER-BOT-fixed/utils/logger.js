const chalk = require('chalk');

function timestamp() {
  return new Date().toLocaleTimeString();
}

module.exports = {
  info: (...args) => console.log(chalk.cyan(`[${timestamp()}] [INFO]`), ...args),
  success: (...args) => console.log(chalk.green(`[${timestamp()}] [OK]`), ...args),
  warn: (...args) => console.log(chalk.yellow(`[${timestamp()}] [WARN]`), ...args),
  error: (...args) => console.log(chalk.red(`[${timestamp()}] [ERROR]`), ...args),
  cmd: (...args) => console.log(chalk.magenta(`[${timestamp()}] [CMD]`), ...args),
};
