const { getMediaBuffer } = require('../../utils/media');
const ff = require('../../utils/ffmpeg');

const voice = {
  name: 'voice',
  aliases: ['tovn', 'tovoicenote'],
  category: 'media',
  description: 'Convert a replied audio file into a WhatsApp voice note.',
  usage: 'Reply to audio with .voice',
  execute: async (ctx) => {
    const media = await getMediaBuffer(ctx.msg, ctx.sock.logger);
    if (!media || media.type !== 'audioMessage') return ctx.reply('Reply to an audio file with .voice');
    const ogg = await ff.toVoiceNote(media.buffer);
    await ctx.sock.sendMessage(ctx.from, { audio: ogg, ptt: true, mimetype: 'audio/ogg; codecs=opus' }, { quoted: ctx.msg });
  },
};

const toaudio = {
  name: 'toaudio',
  aliases: ['tomp3'],
  category: 'media',
  description: 'Convert a voice note into a normal MP3 audio file.',
  usage: 'Reply to a voice note with .toaudio',
  execute: async (ctx) => {
    const media = await getMediaBuffer(ctx.msg, ctx.sock.logger);
    if (!media || media.type !== 'audioMessage') return ctx.reply('Reply to a voice note/audio with .toaudio');
    const mp3 = await ff.toMp3(media.buffer);
    await ctx.sock.sendMessage(ctx.from, { audio: mp3, mimetype: 'audio/mpeg' }, { quoted: ctx.msg });
  },
};

const tovideo = {
  name: 'tovideo',
  aliases: ['gif'],
  category: 'media',
  description: 'Convert a GIF/animated media into an MP4 video.',
  usage: 'Reply to a GIF/video with .tovideo',
  execute: async (ctx) => {
    const media = await getMediaBuffer(ctx.msg, ctx.sock.logger);
    if (!media) return ctx.reply('Reply to a GIF or short clip with .tovideo');
    const mp4 = await ff.toMp4(media.buffer, media.type === 'videoMessage' ? 'mp4' : 'gif');
    await ctx.sock.sendMessage(ctx.from, { video: mp4, gifPlayback: true }, { quoted: ctx.msg });
  },
};

module.exports = [voice, toaudio, tovideo];
