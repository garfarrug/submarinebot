const dl = require('../../utils/downloader');

function firstUrl(candidates) {
  for (const c of candidates) {
    if (typeof c === 'string' && c) return c;
  }
  return null;
}

const tiktok = {
  name: 'tiktok',
  category: 'download',
  description: 'Download a TikTok video (no watermark, where available).',
  usage: '.tiktok <link>',
  example: '.tiktok https://tiktok.com/video/example',
  execute: async (ctx) => {
    const url = ctx.args[0];
    if (!url) return ctx.reply('Usage: .tiktok <link>');
    await ctx.reply('Downloading TikTok video...');
    const res = await dl.downloadTiktok(url);
    if (!res.ok) return ctx.reply(`❌ Download failed: ${res.error}`);
    const video = firstUrl([res.data.video, res.data.video_hd, res.data?.data?.play]);
    if (!video) return ctx.reply('❌ No downloadable video found for that link.');
    await ctx.sock.sendMessage(ctx.from, { video: { url: video }, caption: 'Completed ✅' }, { quoted: ctx.msg });
  },
};

const instagram = {
  name: 'instagram',
  aliases: ['ig'],
  category: 'download',
  description: 'Download Instagram posts, reels, and videos.',
  usage: '.instagram <link>',
  execute: async (ctx) => {
    const url = ctx.args[0];
    if (!url) return ctx.reply('Usage: .instagram <link>');
    await ctx.reply('Downloading Instagram media...');
    const res = await dl.downloadInstagram(url);
    if (!res.ok) return ctx.reply(`❌ Download failed: ${res.error}`);
    const items = Array.isArray(res.data) ? res.data : [res.data];
    for (const item of items) {
      const u = item.url || item.video || item.image;
      if (!u) continue;
      const isVideo = /\.mp4($|\?)/i.test(u) || item.type === 'video';
      await ctx.sock.sendMessage(ctx.from, isVideo ? { video: { url: u } } : { image: { url: u } }, { quoted: ctx.msg });
    }
  },
};

const facebook = {
  name: 'facebook',
  aliases: ['fb'],
  category: 'download',
  description: 'Download Facebook videos.',
  usage: '.facebook <link>',
  execute: async (ctx) => {
    const url = ctx.args[0];
    if (!url) return ctx.reply('Usage: .facebook <link>');
    await ctx.reply('Downloading Facebook video...');
    const res = await dl.downloadFacebook(url);
    if (!res.ok) return ctx.reply(`❌ Download failed: ${res.error}`);
    const video = firstUrl([res.data.HD, res.data.hd, res.data.SD, res.data.sd]);
    if (!video) return ctx.reply('❌ No downloadable video found for that link.');
    await ctx.sock.sendMessage(ctx.from, { video: { url: video }, caption: 'Completed ✅' }, { quoted: ctx.msg });
  },
};

const twitter = {
  name: 'twitter',
  aliases: ['x'],
  category: 'download',
  description: 'Download Twitter/X media.',
  usage: '.twitter <link>',
  execute: async (ctx) => {
    const url = ctx.args[0];
    if (!url) return ctx.reply('Usage: .twitter <link>');
    await ctx.reply('Downloading Twitter/X media...');
    const res = await dl.downloadTwitter(url);
    if (!res.ok) return ctx.reply(`❌ Download failed: ${res.error}`);
    const items = Array.isArray(res.data) ? res.data : [res.data];
    const video = firstUrl(items.map((i) => i.url || i.hd || i.sd));
    if (!video) return ctx.reply('❌ No downloadable media found for that link.');
    await ctx.sock.sendMessage(ctx.from, { video: { url: video }, caption: 'Completed ✅' }, { quoted: ctx.msg });
  },
};

const mediafire = {
  name: 'mediafire',
  category: 'download',
  description: 'Download a file hosted on MediaFire.',
  usage: '.mediafire <link>',
  execute: async (ctx) => {
    const url = ctx.args[0];
    if (!url) return ctx.reply('Usage: .mediafire <link>');
    await ctx.reply('Fetching MediaFire file...');
    const res = await dl.downloadMediafire(url);
    if (!res.ok) return ctx.reply(`❌ Download failed: ${res.error}`);
    const link = res.data.url || res.data.link;
    if (!link) return ctx.reply('❌ Could not resolve that MediaFire link.');
    await ctx.sock.sendMessage(
      ctx.from,
      { document: { url: link }, fileName: res.data.fileName || 'file', mimetype: res.data.mimeType || 'application/octet-stream' },
      { quoted: ctx.msg }
    );
  },
};

async function ytmp3Handler(ctx) {
  const url = ctx.args[0];
  if (!url) return ctx.reply('Usage: .ytmp3 <link>');
  await ctx.reply('Downloading audio...');
  const res = await dl.youtubeAudio(url);
  if (!res.ok) return ctx.reply(`❌ Download failed: ${res.error}`);
  const audio = res.data.url || res.data.audio;
  if (!audio) return ctx.reply('❌ No downloadable audio found for that link.');
  await ctx.sock.sendMessage(ctx.from, { audio: { url: audio }, mimetype: 'audio/mpeg' }, { quoted: ctx.msg });
}

async function ytmp4Handler(ctx) {
  const url = ctx.args[0];
  if (!url) return ctx.reply('Usage: .ytmp4 <link>');
  await ctx.reply('Downloading video...');
  const res = await dl.youtubeVideo(url);
  if (!res.ok) return ctx.reply(`❌ Download failed: ${res.error}`);
  const video = res.data.url || res.data.video;
  if (!video) return ctx.reply('❌ No downloadable video found for that link.');
  await ctx.sock.sendMessage(ctx.from, { video: { url: video }, caption: 'Completed ✅' }, { quoted: ctx.msg });
}

const youtube = {
  name: 'youtube',
  category: 'download',
  description: 'Download a YouTube video.',
  usage: '.youtube <link>',
  execute: ytmp4Handler,
};

const ytmp3 = {
  name: 'ytmp3',
  category: 'download',
  description: 'Download YouTube audio as MP3.',
  usage: '.ytmp3 <link>',
  execute: ytmp3Handler,
};

const ytmp4 = {
  name: 'ytmp4',
  category: 'download',
  description: 'Download a YouTube video (mp4).',
  usage: '.ytmp4 <link>',
  execute: ytmp4Handler,
};

const play = {
  name: 'play',
  aliases: ['song'],
  category: 'download',
  description: 'Search YouTube and send back the top match as audio.',
  usage: '.play <song name>',
  example: '.play Perfect Ed Sheeran',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .play <song name>');
    const results = await dl.searchYoutube(ctx.fullArgs, 1);
    if (!results.length) return ctx.reply('❌ No results found.');
    await ctx.reply(`🔎 Found: ${results[0].title} (${results[0].duration})\nDownloading...`);
    const res = await dl.youtubeAudio(results[0].url);
    if (!res.ok) return ctx.reply(`❌ Download failed: ${res.error}`);
    const audio = res.data.url || res.data.audio;
    if (!audio) return ctx.reply('❌ No downloadable audio found.');
    await ctx.sock.sendMessage(ctx.from, { audio: { url: audio }, mimetype: 'audio/mpeg' }, { quoted: ctx.msg });
  },
};

const video = {
  name: 'video',
  category: 'download',
  description: 'Search YouTube videos by name.',
  usage: '.video <name>',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .video <name>');
    const results = await dl.searchYoutube(ctx.fullArgs, 5);
    if (!results.length) return ctx.reply('❌ No results found.');
    const text = results.map((r, i) => `${i + 1}. ${r.title} (${r.duration})\n${r.url}`).join('\n\n');
    await ctx.reply(text);
  },
};

const song = {
  ...ytmp3,
  name: 'song',
  description: 'Search and download a song by name (audio).',
  usage: '.song <song name>',
  example: '.song Perfect Ed Sheeran',
};

module.exports = [tiktok, instagram, facebook, twitter, mediafire, youtube, ytmp3, ytmp4, play, video, song];
