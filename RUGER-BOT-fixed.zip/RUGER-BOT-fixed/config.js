/**
 * RUGER BOT - Global Configuration
 * Edit these values or override with environment variables.
 *
 * A handful of fields (OWNER_NUMBER, PREFIX, BOT_NAME, SESSION_DIR) can be
 * overridden per-session when the bot is run in multi-tenant "pairing site"
 * mode (see utils/sessionManager.js + server.js). Everything else stays a
 * plain global value. This is done via a Proxy so existing code that does
 * `config.OWNER_NUMBER` etc. keeps working unchanged in both modes.
 */
const sessionContext = require('./utils/sessionContext');

const base = {
  BOT_NAME: process.env.BOT_NAME || 'RUGER',
  PREFIX: process.env.PREFIX || '.',

  // Owner identity
  OWNER_NAME: process.env.OWNER_NAME || 'Garfar',
  OWNER_USERNAME: process.env.OWNER_USERNAME || '@submarineboy1',
  OWNER_NUMBER: process.env.OWNER_NUMBER || '', // e.g. 233XXXXXXXXX (digits only, no +)

  // Session
  SESSION_DIR: process.env.SESSION_DIR || './sessions',
  USE_PAIRING_CODE: (process.env.USE_PAIRING_CODE || 'true') === 'true',
  PAIR_NUMBER: process.env.PAIR_NUMBER || '', // number to request a pairing code for

  // Default runtime settings (persisted to database/settings.json on first boot)
  DEFAULTS: {
    mode: 'public', // public | private | chat | group | command
    autoRead: true,
    alwaysOnline: false,
    autoReact: true,
    reactEmoji: '✅',
    autoType: 'off', // group | chat | all | off
    autoRecord: 'off', // group | chat | all | off
    autoViewStatus: false,
    statusDelay: 5,
    autoLikeStatus: false,
    statusLikeEmoji: '💚',
    font: 'normal',
    stickerName: 'RUGER BOT',
    stickerAuthor: 'RUGER',
    watermark: '',
    prefix: '', // empty = use the base PREFIX above; set via .setprefix to override
    maintenance: false,
    maintenanceMessage: '🛠️ The bot is under maintenance right now. Please try again later.',
    antiViewOnce: 'off', // off | all | group | chat — see .antiviewonce (self-sent media only)
  },

  // Warnings before auto-action (kick) in group moderation
  MAX_WARNINGS: 3,

  // Anti-spam thresholds
  ANTISPAM_MSG_LIMIT: 8, // messages
  ANTISPAM_WINDOW_MS: 10_000, // per this window
};

// Fields a session may override. Anything not in this set always falls
// back to the base/global value above.
const PER_SESSION_KEYS = new Set(['OWNER_NUMBER', 'PREFIX', 'BOT_NAME', 'SESSION_DIR']);

const config = new Proxy(base, {
  get(target, prop) {
    if (PER_SESSION_KEYS.has(prop)) {
      const store = sessionContext.getStore();
      if (store && store.config && prop in store.config) {
        return store.config[prop];
      }
    }
    return target[prop];
  },
});

module.exports = config;
