const db = require('../../utils/database');
const { setSetting } = require('../../utils/settings');
const permissions = require('../../utils/permissions');

const setownername = {
  name: 'setownername',
  category: 'owner',
  ownerOnly: true,
  description: 'Change owner display name.',
  usage: '.setownername <name>',
  example: '.setownername Garfar',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .setownername <name>');
    db.setPath('settings', 'ownerName', ctx.fullArgs);
    await ctx.reply('Owner name updated.');
  },
};

const setownerphone = {
  name: 'setownerphone',
  category: 'owner',
  ownerOnly: true,
  description: 'Set owner WhatsApp number.',
  usage: '.setownerphone <number>',
  example: '.setownerphone +233XXXXXXXXX',
  execute: async (ctx) => {
    const num = (ctx.args[0] || '').replace(/[^0-9]/g, '');
    if (!num) return ctx.reply('Usage: .setownerphone <number>');
    db.setPath('settings', 'ownerPhone', num);
    await ctx.reply('Owner phone number updated.');
  },
};

const setaccount = {
  name: 'setaccount',
  category: 'owner',
  ownerOnly: true,
  description: 'Save owner payment details (name, number, bank/network).',
  usage: '.setaccount Name|Number|Network',
  example: '.setaccount Garfar|024XXXXXXX|MTN',
  execute: async (ctx) => {
    const [name, number, network] = ctx.fullArgs.split('|').map((s) => s?.trim());
    if (!name || !number || !network) {
      return ctx.reply('Usage: .setaccount Name|Number|Network\nExample: .setaccount Garfar|024XXXXXXX|MTN');
    }
    db.setPath('settings', 'account', { name, number, network });
    await ctx.reply('Account details saved.');
  },
};

const accountnumber = {
  name: 'accountnumber',
  aliases: ['aza', 'account', 'momo', 'acc'],
  category: 'owner',
  description: "Show the owner's saved payment/account details (set via .setaccount).",
  usage: '.accountnumber',
  execute: async (ctx) => {
    const acc = db.getPath('settings', 'account', null);
    if (!acc) {
      return ctx.reply(
        `❌ No account details have been saved yet.${
          ctx.isOwnerOrSudo ? `\n\nSet one with:\n${ctx.prefix}setaccount Name|Number|Network` : ''
        }`
      );
    }
    await ctx.reply(
      `╭━━━━━━━━━━━━━━╮\n┃ 💳 ACCOUNT DETAILS ┃\n╰━━━━━━━━━━━━━━╯\n\nName:\n${acc.name}\n\nNumber:\n${acc.number}\n\nNetwork:\n${acc.network}`
    );
  },
};

const addsudo = {
  name: 'addsudo',
  category: 'owner',
  ownerOnly: true,
  description: 'Add a trusted user who can control the bot without being owner.',
  usage: '.addsudo <number>',
  example: '.addsudo 233XXXXXXXXX',
  execute: async (ctx) => {
    const num = (ctx.args[0] || '').replace(/[^0-9]/g, '');
    if (!num) return ctx.reply('Usage: .addsudo <number>');
    const store = db.get('sudo', { users: [] });
    if (!store.users.includes(num)) store.users.push(num);
    db.persist('sudo');
    await ctx.reply(`✅ ${num} added as sudo.`);
  },
};

const delsudo = {
  name: 'delsudo',
  category: 'owner',
  ownerOnly: true,
  description: 'Remove a sudo user.',
  usage: '.delsudo <number>',
  execute: async (ctx) => {
    const num = (ctx.args[0] || '').replace(/[^0-9]/g, '');
    const store = db.get('sudo', { users: [] });
    store.users = store.users.filter((u) => u !== num);
    db.persist('sudo');
    await ctx.reply(`✅ ${num} removed from sudo.`);
  },
};

const listsudo = {
  name: 'listsudo',
  category: 'owner',
  ownerOnly: true,
  description: 'Show sudo users.',
  usage: '.listsudo',
  execute: async (ctx) => {
    const store = db.get('sudo', { users: [] });
    await ctx.reply(store.users.length ? `Sudo users:\n${store.users.join('\n')}` : 'No sudo users set.');
  },
};

const mode = {
  name: 'mode',
  category: 'owner',
  ownerOnly: true,
  description: 'Change bot availability mode.',
  usage: '.mode <private|public|chat|group|command>',
  example: '.mode private',
  execute: async (ctx) => {
    const valid = ['private', 'public', 'chat', 'group', 'command'];
    const m = (ctx.args[0] || '').toLowerCase();
    if (!valid.includes(m)) return ctx.reply(`Usage: .mode <${valid.join('|')}>`);
    setSetting('mode', m);
    await ctx.reply(`Bot mode changed:\n${m.toUpperCase()}`);
  },
};

const setfont = {
  name: 'setfont',
  category: 'owner',
  ownerOnly: true,
  description: 'Change bot text style used in generated replies.',
  usage: '.setfont <normal|bold|fancy|gothic|bubble|small>',
  example: '.setfont gothic',
  execute: async (ctx) => {
    const valid = ['normal', 'bold', 'fancy', 'gothic', 'bubble', 'small'];
    const f = (ctx.args[0] || '').toLowerCase();
    if (!valid.includes(f)) return ctx.reply(`Available: ${valid.join(', ')}`);
    setSetting('font', f);
    await ctx.reply(`Font style set to: ${f}`);
  },
};

module.exports = [setownername, setownerphone, setaccount, accountnumber, addsudo, delsudo, listsudo, mode, setfont];
