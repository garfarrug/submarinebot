const { getGroupConfig } = require('./_welcome');
const db = require('../../utils/database');

function targetJids(ctx) {
  if (ctx.mentionedJid?.length) return ctx.mentionedJid;
  const quotedParticipant = ctx.msg.message?.extendedTextMessage?.contextInfo?.participant;
  if (quotedParticipant) return [quotedParticipant];
  return [];
}

const kick = {
  name: 'kick',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Remove a member from a group.',
  usage: '.kick @user',
  example: '.kick @John',
  execute: async (ctx) => {
    const targets = targetJids(ctx);
    if (!targets.length) return ctx.reply('Usage: .kick @user');
    if (!ctx.isBotAdmin) return ctx.reply('❌ I need to be admin to do that.');
    await ctx.sock.groupParticipantsUpdate(ctx.from, targets, 'remove');
    await ctx.reply(
      `╭━━━━━━━━━━━━━━╮\n┃ MEMBER REMOVED ┃\n╰━━━━━━━━━━━━━━╯\n\nUser:\n@${targets[0].split('@')[0]}\n\nAction:\nKicked successfully`
    );
  },
};

const add = {
  name: 'add',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Add a member to the group.',
  usage: '.add <number>',
  example: '.add 233XXXXXXXXX',
  execute: async (ctx) => {
    const num = (ctx.args[0] || '').replace(/[^0-9]/g, '');
    if (!num) return ctx.reply('Usage: .add <number>');
    if (!ctx.isBotAdmin) return ctx.reply('❌ I need to be admin to do that.');
    await ctx.sock.groupParticipantsUpdate(ctx.from, [`${num}@s.whatsapp.net`], 'add');
    await ctx.reply('Member added successfully.');
  },
};

const promote = {
  name: 'promote',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Promote a member to group admin.',
  usage: '.promote @user',
  execute: async (ctx) => {
    const targets = targetJids(ctx);
    if (!targets.length) return ctx.reply('Usage: .promote @user');
    if (!ctx.isBotAdmin) return ctx.reply('❌ I need to be admin to do that.');
    await ctx.sock.groupParticipantsUpdate(ctx.from, targets, 'promote');
    await ctx.reply(`@${targets[0].split('@')[0]} is now an admin.`, );
  },
};

const demote = {
  name: 'demote',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Remove admin status from a member.',
  usage: '.demote @user',
  execute: async (ctx) => {
    const targets = targetJids(ctx);
    if (!targets.length) return ctx.reply('Usage: .demote @user');
    if (!ctx.isBotAdmin) return ctx.reply('❌ I need to be admin to do that.');
    await ctx.sock.groupParticipantsUpdate(ctx.from, targets, 'demote');
    await ctx.reply('Admin permission removed.');
  },
};

const tagall = {
  name: 'tagall',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Mention every group member.',
  usage: '.tagall',
  execute: async (ctx) => {
    const participants = ctx.groupMetadata.participants.map((p) => p.id);
    const text = `Attention everyone:\n\n${participants.map((p) => `@${p.split('@')[0]}`).join('\n')}`;
    await ctx.sock.sendMessage(ctx.from, { text, mentions: participants }, { quoted: ctx.msg });
  },
};

const hidetag = {
  name: 'hidetag',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Mention everyone without showing visible tags.',
  usage: '.hidetag <message>',
  example: '.hidetag Meeting starts now',
  execute: async (ctx) => {
    const participants = ctx.groupMetadata.participants.map((p) => p.id);
    await ctx.sock.sendMessage(ctx.from, { text: ctx.fullArgs || '\u200B', mentions: participants }, { quoted: ctx.msg });
    if (!ctx.fullArgs) return; // message already sent silently
  },
};

const mute = {
  name: 'mute',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Group admins only can send messages (alias of close).',
  usage: '.mute',
  execute: async (ctx) => {
    if (!ctx.isBotAdmin) return ctx.reply('❌ I need to be admin to do that.');
    await ctx.sock.groupSettingUpdate(ctx.from, 'announcement');
    await ctx.reply('User muted.');
  },
};

const unmute = {
  name: 'unmute',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Allow members to send messages again.',
  usage: '.unmute',
  execute: async (ctx) => {
    if (!ctx.isBotAdmin) return ctx.reply('❌ I need to be admin to do that.');
    await ctx.sock.groupSettingUpdate(ctx.from, 'not_announcement');
    await ctx.reply('User unmuted.');
  },
};

const open = {
  name: 'open',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Allow everyone to send messages.',
  usage: '.open',
  execute: async (ctx) => {
    if (!ctx.isBotAdmin) return ctx.reply('❌ I need to be admin to do that.');
    await ctx.sock.groupSettingUpdate(ctx.from, 'not_announcement');
    await ctx.reply('Group opened.');
  },
};

const close = {
  name: 'close',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Only admins can send messages.',
  usage: '.close',
  execute: async (ctx) => {
    if (!ctx.isBotAdmin) return ctx.reply('❌ I need to be admin to do that.');
    await ctx.sock.groupSettingUpdate(ctx.from, 'announcement');
    await ctx.reply('Group closed.');
  },
};

const group = {
  name: 'group',
  category: 'group',
  groupOnly: true,
  description: 'Show group information.',
  usage: '.group',
  execute: async (ctx) => {
    const gm = ctx.groupMetadata;
    const admins = gm.participants.filter((p) => p.admin).length;
    await ctx.reply(`GROUP INFO\n\nName:\n${gm.subject}\n\nMembers:\n${gm.participants.length}\n\nAdmins:\n${admins}`);
  },
};

const link = {
  name: 'link',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Get the group invite link.',
  usage: '.link',
  execute: async (ctx) => {
    const code = await ctx.sock.groupInviteCode(ctx.from);
    await ctx.reply(`Group link generated.\n\nhttps://chat.whatsapp.com/${code}`);
  },
};

const revoke = {
  name: 'revoke',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Reset the group invite link.',
  usage: '.revoke',
  execute: async (ctx) => {
    await ctx.sock.groupRevokeInvite(ctx.from);
    await ctx.reply('Invite link revoked.');
  },
};

const welcome = {
  name: 'welcome',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Enable/disable welcome messages for new members.',
  usage: '.welcome on|off',
  execute: async (ctx) => {
    const v = (ctx.args[0] || '').toLowerCase();
    if (v !== 'on' && v !== 'off') return ctx.reply('Usage: .welcome on|off');
    const cfg = getGroupConfig(ctx.from);
    cfg.welcome = v === 'on';
    db.setPath('groups', ctx.from, cfg);
    await ctx.reply(`Welcome system ${v === 'on' ? 'enabled' : 'disabled'}.`);
  },
};

const goodbye = {
  name: 'goodbye',
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: 'Enable/disable goodbye messages for leaving members.',
  usage: '.goodbye on|off',
  execute: async (ctx) => {
    const v = (ctx.args[0] || '').toLowerCase();
    if (v !== 'on' && v !== 'off') return ctx.reply('Usage: .goodbye on|off');
    const cfg = getGroupConfig(ctx.from);
    cfg.goodbye = v === 'on';
    db.setPath('groups', ctx.from, cfg);
    await ctx.reply(`Goodbye system ${v === 'on' ? 'enabled' : 'disabled'}.`);
  },
};

const block = {
  name: 'block',
  category: 'group',
  ownerOnly: true,
  description: 'Block a user.',
  usage: '.block <number>',
  execute: async (ctx) => {
    const num = (ctx.args[0] || '').replace(/[^0-9]/g, '');
    if (!num) return ctx.reply('Usage: .block <number>');
    await ctx.sock.updateBlockStatus(`${num}@s.whatsapp.net`, 'block');
    await ctx.reply(`Blocked ${num}.`);
  },
};

const unblock = {
  name: 'unblock',
  category: 'group',
  ownerOnly: true,
  description: 'Unblock a user.',
  usage: '.unblock <number>',
  execute: async (ctx) => {
    const num = (ctx.args[0] || '').replace(/[^0-9]/g, '');
    if (!num) return ctx.reply('Usage: .unblock <number>');
    await ctx.sock.updateBlockStatus(`${num}@s.whatsapp.net`, 'unblock');
    await ctx.reply(`Unblocked ${num}.`);
  },
};

const setgname = {
  name: 'setgname',
  aliases: ['setgroupname', 'setsubject'],
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: "Change the group's name.",
  usage: '.setgname <new name>',
  example: '.setgname RUGER Squad',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .setgname <new name>');
    if (!ctx.isBotAdmin) return ctx.reply('❌ I need to be admin to do that.');
    await ctx.sock.groupUpdateSubject(ctx.from, ctx.fullArgs);
    await ctx.reply('✅ Group name updated.');
  },
};

const setgdesc = {
  name: 'setgdesc',
  aliases: ['setgroupdesc', 'setdescription'],
  category: 'group',
  groupOnly: true,
  adminOnly: true,
  description: "Change the group's description.",
  usage: '.setgdesc <new description>',
  execute: async (ctx) => {
    if (!ctx.fullArgs) return ctx.reply('Usage: .setgdesc <new description>');
    if (!ctx.isBotAdmin) return ctx.reply('❌ I need to be admin to do that.');
    await ctx.sock.groupUpdateDescription(ctx.from, ctx.fullArgs);
    await ctx.reply('✅ Group description updated.');
  },
};

module.exports = [
  kick, add, promote, demote, tagall, hidetag, mute, unmute, open, close,
  group, link, revoke, welcome, goodbye, block, unblock, setgname, setgdesc,
];
